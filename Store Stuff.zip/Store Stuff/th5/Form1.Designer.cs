﻿namespace th5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_main = new System.Windows.Forms.Panel();
            this.dtgv_product = new System.Windows.Forms.DataGridView();
            this.lb_productinfo = new System.Windows.Forms.Label();
            this.bt_selectall = new System.Windows.Forms.Button();
            this.bt_selectfilter = new System.Windows.Forms.Button();
            this.cbx_filter = new System.Windows.Forms.ComboBox();
            this.lb_ctginfo = new System.Windows.Forms.Label();
            this.dtgv_ctg = new System.Windows.Forms.DataGridView();
            this.tx_ctgname = new System.Windows.Forms.TextBox();
            this.lb_ctgnameinfo = new System.Windows.Forms.Label();
            this.bt_ctgadd = new System.Windows.Forms.Button();
            this.bt_ctgdel = new System.Windows.Forms.Button();
            this.lb_dtlinfo = new System.Windows.Forms.Label();
            this.tx_productname = new System.Windows.Forms.TextBox();
            this.tx_productprice = new System.Windows.Forms.TextBox();
            this.tx_productstock = new System.Windows.Forms.TextBox();
            this.cbx_productctg = new System.Windows.Forms.ComboBox();
            this.bt_productadd = new System.Windows.Forms.Button();
            this.bt_productdel = new System.Windows.Forms.Button();
            this.bt_productedit = new System.Windows.Forms.Button();
            this.lb_productnameinfo = new System.Windows.Forms.Label();
            this.lb_productctginfo = new System.Windows.Forms.Label();
            this.lb_producthargainfo = new System.Windows.Forms.Label();
            this.lb_productstockinfo = new System.Windows.Forms.Label();
            this.pnl_main.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_ctg)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl_main
            // 
            this.pnl_main.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnl_main.Controls.Add(this.lb_productstockinfo);
            this.pnl_main.Controls.Add(this.lb_producthargainfo);
            this.pnl_main.Controls.Add(this.lb_productctginfo);
            this.pnl_main.Controls.Add(this.lb_productnameinfo);
            this.pnl_main.Controls.Add(this.bt_productedit);
            this.pnl_main.Controls.Add(this.bt_productdel);
            this.pnl_main.Controls.Add(this.bt_productadd);
            this.pnl_main.Controls.Add(this.cbx_productctg);
            this.pnl_main.Controls.Add(this.tx_productstock);
            this.pnl_main.Controls.Add(this.tx_productprice);
            this.pnl_main.Controls.Add(this.tx_productname);
            this.pnl_main.Controls.Add(this.lb_dtlinfo);
            this.pnl_main.Controls.Add(this.bt_ctgdel);
            this.pnl_main.Controls.Add(this.bt_ctgadd);
            this.pnl_main.Controls.Add(this.lb_ctgnameinfo);
            this.pnl_main.Controls.Add(this.tx_ctgname);
            this.pnl_main.Controls.Add(this.dtgv_ctg);
            this.pnl_main.Controls.Add(this.lb_ctginfo);
            this.pnl_main.Controls.Add(this.cbx_filter);
            this.pnl_main.Controls.Add(this.bt_selectfilter);
            this.pnl_main.Controls.Add(this.bt_selectall);
            this.pnl_main.Controls.Add(this.lb_productinfo);
            this.pnl_main.Controls.Add(this.dtgv_product);
            this.pnl_main.Location = new System.Drawing.Point(4, 4);
            this.pnl_main.Name = "pnl_main";
            this.pnl_main.Size = new System.Drawing.Size(873, 525);
            this.pnl_main.TabIndex = 0;
            // 
            // dtgv_product
            // 
            this.dtgv_product.AllowUserToAddRows = false;
            this.dtgv_product.AllowUserToDeleteRows = false;
            this.dtgv_product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_product.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtgv_product.Location = new System.Drawing.Point(18, 52);
            this.dtgv_product.Name = "dtgv_product";
            this.dtgv_product.Size = new System.Drawing.Size(537, 299);
            this.dtgv_product.TabIndex = 0;
            this.dtgv_product.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_product_CellClick);
            // 
            // lb_productinfo
            // 
            this.lb_productinfo.AutoSize = true;
            this.lb_productinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_productinfo.Location = new System.Drawing.Point(14, 20);
            this.lb_productinfo.Name = "lb_productinfo";
            this.lb_productinfo.Size = new System.Drawing.Size(71, 20);
            this.lb_productinfo.TabIndex = 1;
            this.lb_productinfo.Text = "Product";
            // 
            // bt_selectall
            // 
            this.bt_selectall.Location = new System.Drawing.Point(343, 23);
            this.bt_selectall.Name = "bt_selectall";
            this.bt_selectall.Size = new System.Drawing.Size(45, 23);
            this.bt_selectall.TabIndex = 2;
            this.bt_selectall.Text = "All";
            this.bt_selectall.UseVisualStyleBackColor = true;
            this.bt_selectall.Click += new System.EventHandler(this.bt_selectall_Click);
            // 
            // bt_selectfilter
            // 
            this.bt_selectfilter.Location = new System.Drawing.Point(394, 23);
            this.bt_selectfilter.Name = "bt_selectfilter";
            this.bt_selectfilter.Size = new System.Drawing.Size(46, 23);
            this.bt_selectfilter.TabIndex = 3;
            this.bt_selectfilter.Text = "Filter";
            this.bt_selectfilter.UseVisualStyleBackColor = true;
            this.bt_selectfilter.Click += new System.EventHandler(this.bt_selectfilter_Click);
            // 
            // cbx_filter
            // 
            this.cbx_filter.FormattingEnabled = true;
            this.cbx_filter.Location = new System.Drawing.Point(446, 23);
            this.cbx_filter.Name = "cbx_filter";
            this.cbx_filter.Size = new System.Drawing.Size(108, 21);
            this.cbx_filter.TabIndex = 4;
            this.cbx_filter.SelectedIndexChanged += new System.EventHandler(this.cbx_filter_SelectedIndexChanged);
            // 
            // lb_ctginfo
            // 
            this.lb_ctginfo.AutoSize = true;
            this.lb_ctginfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ctginfo.Location = new System.Drawing.Point(603, 26);
            this.lb_ctginfo.Name = "lb_ctginfo";
            this.lb_ctginfo.Size = new System.Drawing.Size(81, 20);
            this.lb_ctginfo.TabIndex = 5;
            this.lb_ctginfo.Text = "Category";
            // 
            // dtgv_ctg
            // 
            this.dtgv_ctg.AllowUserToAddRows = false;
            this.dtgv_ctg.AllowUserToDeleteRows = false;
            this.dtgv_ctg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_ctg.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtgv_ctg.Location = new System.Drawing.Point(607, 52);
            this.dtgv_ctg.Name = "dtgv_ctg";
            this.dtgv_ctg.Size = new System.Drawing.Size(243, 239);
            this.dtgv_ctg.TabIndex = 6;
            this.dtgv_ctg.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_ctg_CellClick);
            // 
            // tx_ctgname
            // 
            this.tx_ctgname.Location = new System.Drawing.Point(651, 302);
            this.tx_ctgname.Name = "tx_ctgname";
            this.tx_ctgname.Size = new System.Drawing.Size(132, 20);
            this.tx_ctgname.TabIndex = 7;
            // 
            // lb_ctgnameinfo
            // 
            this.lb_ctgnameinfo.AutoSize = true;
            this.lb_ctgnameinfo.Location = new System.Drawing.Point(604, 305);
            this.lb_ctgnameinfo.Name = "lb_ctgnameinfo";
            this.lb_ctgnameinfo.Size = new System.Drawing.Size(41, 13);
            this.lb_ctgnameinfo.TabIndex = 8;
            this.lb_ctgnameinfo.Text = "Nama :";
            // 
            // bt_ctgadd
            // 
            this.bt_ctgadd.Location = new System.Drawing.Point(651, 328);
            this.bt_ctgadd.Name = "bt_ctgadd";
            this.bt_ctgadd.Size = new System.Drawing.Size(63, 42);
            this.bt_ctgadd.TabIndex = 9;
            this.bt_ctgadd.Text = "Add";
            this.bt_ctgadd.UseVisualStyleBackColor = true;
            this.bt_ctgadd.Click += new System.EventHandler(this.bt_ctgadd_Click);
            // 
            // bt_ctgdel
            // 
            this.bt_ctgdel.Location = new System.Drawing.Point(720, 328);
            this.bt_ctgdel.Name = "bt_ctgdel";
            this.bt_ctgdel.Size = new System.Drawing.Size(63, 42);
            this.bt_ctgdel.TabIndex = 10;
            this.bt_ctgdel.Text = "Remove";
            this.bt_ctgdel.UseVisualStyleBackColor = true;
            this.bt_ctgdel.Click += new System.EventHandler(this.bt_ctgdel_Click);
            // 
            // lb_dtlinfo
            // 
            this.lb_dtlinfo.AutoSize = true;
            this.lb_dtlinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_dtlinfo.Location = new System.Drawing.Point(14, 368);
            this.lb_dtlinfo.Name = "lb_dtlinfo";
            this.lb_dtlinfo.Size = new System.Drawing.Size(65, 20);
            this.lb_dtlinfo.TabIndex = 11;
            this.lb_dtlinfo.Text = "Details";
            // 
            // tx_productname
            // 
            this.tx_productname.Location = new System.Drawing.Point(68, 402);
            this.tx_productname.Name = "tx_productname";
            this.tx_productname.Size = new System.Drawing.Size(174, 20);
            this.tx_productname.TabIndex = 12;
            // 
            // tx_productprice
            // 
            this.tx_productprice.Location = new System.Drawing.Point(68, 455);
            this.tx_productprice.Name = "tx_productprice";
            this.tx_productprice.Size = new System.Drawing.Size(121, 20);
            this.tx_productprice.TabIndex = 13;
            this.tx_productprice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_productprice_KeyPress);
            // 
            // tx_productstock
            // 
            this.tx_productstock.Location = new System.Drawing.Point(68, 481);
            this.tx_productstock.Name = "tx_productstock";
            this.tx_productstock.Size = new System.Drawing.Size(121, 20);
            this.tx_productstock.TabIndex = 14;
            this.tx_productstock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_productstock_KeyPress);
            // 
            // cbx_productctg
            // 
            this.cbx_productctg.FormattingEnabled = true;
            this.cbx_productctg.Location = new System.Drawing.Point(68, 428);
            this.cbx_productctg.Name = "cbx_productctg";
            this.cbx_productctg.Size = new System.Drawing.Size(121, 21);
            this.cbx_productctg.TabIndex = 15;
            // 
            // bt_productadd
            // 
            this.bt_productadd.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.bt_productadd.Location = new System.Drawing.Point(195, 428);
            this.bt_productadd.Name = "bt_productadd";
            this.bt_productadd.Size = new System.Drawing.Size(78, 73);
            this.bt_productadd.TabIndex = 16;
            this.bt_productadd.Text = "Add";
            this.bt_productadd.UseVisualStyleBackColor = false;
            this.bt_productadd.Click += new System.EventHandler(this.bt_productadd_Click);
            // 
            // bt_productdel
            // 
            this.bt_productdel.BackColor = System.Drawing.Color.Sienna;
            this.bt_productdel.Location = new System.Drawing.Point(279, 428);
            this.bt_productdel.Name = "bt_productdel";
            this.bt_productdel.Size = new System.Drawing.Size(78, 73);
            this.bt_productdel.TabIndex = 17;
            this.bt_productdel.Text = "Remove";
            this.bt_productdel.UseVisualStyleBackColor = false;
            this.bt_productdel.Click += new System.EventHandler(this.bt_productdel_Click);
            // 
            // bt_productedit
            // 
            this.bt_productedit.BackColor = System.Drawing.Color.Khaki;
            this.bt_productedit.Location = new System.Drawing.Point(362, 428);
            this.bt_productedit.Name = "bt_productedit";
            this.bt_productedit.Size = new System.Drawing.Size(78, 73);
            this.bt_productedit.TabIndex = 18;
            this.bt_productedit.Text = "Edit";
            this.bt_productedit.UseVisualStyleBackColor = false;
            this.bt_productedit.Click += new System.EventHandler(this.bt_productedit_Click);
            // 
            // lb_productnameinfo
            // 
            this.lb_productnameinfo.AutoSize = true;
            this.lb_productnameinfo.Location = new System.Drawing.Point(8, 405);
            this.lb_productnameinfo.Name = "lb_productnameinfo";
            this.lb_productnameinfo.Size = new System.Drawing.Size(41, 13);
            this.lb_productnameinfo.TabIndex = 19;
            this.lb_productnameinfo.Text = "Nama :";
            // 
            // lb_productctginfo
            // 
            this.lb_productctginfo.AutoSize = true;
            this.lb_productctginfo.Location = new System.Drawing.Point(8, 431);
            this.lb_productctginfo.Name = "lb_productctginfo";
            this.lb_productctginfo.Size = new System.Drawing.Size(55, 13);
            this.lb_productctginfo.TabIndex = 20;
            this.lb_productctginfo.Text = "Category :";
            // 
            // lb_producthargainfo
            // 
            this.lb_producthargainfo.AutoSize = true;
            this.lb_producthargainfo.Location = new System.Drawing.Point(8, 458);
            this.lb_producthargainfo.Name = "lb_producthargainfo";
            this.lb_producthargainfo.Size = new System.Drawing.Size(42, 13);
            this.lb_producthargainfo.TabIndex = 21;
            this.lb_producthargainfo.Text = "Harga :";
            // 
            // lb_productstockinfo
            // 
            this.lb_productstockinfo.AutoSize = true;
            this.lb_productstockinfo.Location = new System.Drawing.Point(8, 484);
            this.lb_productstockinfo.Name = "lb_productstockinfo";
            this.lb_productstockinfo.Size = new System.Drawing.Size(35, 13);
            this.lb_productstockinfo.TabIndex = 22;
            this.lb_productstockinfo.Text = "Stok :";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(882, 538);
            this.Controls.Add(this.pnl_main);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pnl_main.ResumeLayout(false);
            this.pnl_main.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_ctg)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_main;
        private System.Windows.Forms.Label lb_productinfo;
        private System.Windows.Forms.DataGridView dtgv_product;
        private System.Windows.Forms.ComboBox cbx_filter;
        private System.Windows.Forms.Button bt_selectfilter;
        private System.Windows.Forms.Button bt_selectall;
        private System.Windows.Forms.Label lb_dtlinfo;
        private System.Windows.Forms.Button bt_ctgdel;
        private System.Windows.Forms.Button bt_ctgadd;
        private System.Windows.Forms.Label lb_ctgnameinfo;
        private System.Windows.Forms.TextBox tx_ctgname;
        private System.Windows.Forms.DataGridView dtgv_ctg;
        private System.Windows.Forms.Label lb_ctginfo;
        private System.Windows.Forms.TextBox tx_productname;
        private System.Windows.Forms.Button bt_productadd;
        private System.Windows.Forms.ComboBox cbx_productctg;
        private System.Windows.Forms.TextBox tx_productstock;
        private System.Windows.Forms.TextBox tx_productprice;
        private System.Windows.Forms.Button bt_productedit;
        private System.Windows.Forms.Button bt_productdel;
        private System.Windows.Forms.Label lb_productstockinfo;
        private System.Windows.Forms.Label lb_producthargainfo;
        private System.Windows.Forms.Label lb_productctginfo;
        private System.Windows.Forms.Label lb_productnameinfo;
    }
}


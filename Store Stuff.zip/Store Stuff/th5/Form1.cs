﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace th5
{
    public partial class Form1 : Form
    {
        DataTable dtsave = new DataTable(); //storing table
        DataTable dtshow = new DataTable(); //showcase table
        DataTable dtcategory = new DataTable(); //category table

        int rowedit;
        int itemctg = 5;

        public Form1()
        {
            InitializeComponent();
            dtgv_ctg.DataSource = dtcategory;

            // stored attributes
            dtsave.Columns.Add("ID Produk");
            dtsave.Columns.Add("Nama");
            dtsave.Columns.Add("Harga");
            dtsave.Columns.Add("Stock Produk");
            dtsave.Columns.Add("ID Kategori");

            // category attributes
            dtcategory.Columns.Add("ID");
            dtcategory.Columns.Add("Nama");

            // combo boxes options
            cbx_productctg.Items.Add("C1");
            cbx_productctg.Items.Add("C2");
            cbx_productctg.Items.Add("C3");
            cbx_productctg.Items.Add("C4");
            cbx_productctg.Items.Add("C5");

            cbx_filter.Items.Add("C1");
            cbx_filter.Items.Add("C2");
            cbx_filter.Items.Add("C3");
            cbx_filter.Items.Add("C4");
            cbx_filter.Items.Add("C5");

            // preset
            dtshow = dtsave;
            dtgv_product.DataSource = dtsave;

            dtcategory.Rows.Add("C1", "Jas");
            dtcategory.Rows.Add("C2", "T-Shirt");
            dtcategory.Rows.Add("C3", "Rok");
            dtcategory.Rows.Add("C4", "Celana");
            dtcategory.Rows.Add("C5", "Cawat");

            dtsave.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dtsave.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dtsave.Rows.Add("T002", "T-Shirt Obsesive", "75000", "16", "C2");
            dtsave.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dtsave.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dtsave.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dtsave.Rows.Add("C002", "Celana Blink-Blink", "1000000", "1", "C5");
            dtsave.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");

        }

        // Product Side
        private void bt_selectall_Click(object sender, EventArgs e)
        {
            cbx_filter.Enabled = false;
            dtgv_product.DataSource = dtshow;
        }

        private void bt_selectfilter_Click(object sender, EventArgs e)
        {
            cbx_filter.Enabled = true;
            dtgv_product.DataSource = dtshow;
        }

        private void cbx_filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            string filter = cbx_filter.SelectedItem.ToString();
            if (filter == null) // if filter has nothing, do nothing
            {
                return;
            }
            DataTable filtered = dtsave.Clone(); // clone original datatable

            foreach (DataRow row in dtsave.Rows)
            {
                if (row["ID Kategori"].ToString() == filter) // row check if match with kategori
                {
                    DataRow newrow = filtered.NewRow();
                    newrow.ItemArray = row.ItemArray;
                    filtered.Rows.Add(newrow);
                }
            }
            dtgv_product.DataSource = filtered;
        }
        private string GenerateId()
        {
            string firstwrd = tx_productname.Text;
            string id = "";
            int unqid = 0;

            // find unqid with first character
            foreach (DataRow row in dtsave.Rows )
            {
                string productid = row["ID Produk"].ToString();
                if (productid.StartsWith(firstwrd[0].ToString()))
                {
                    int num;
                    if (int.TryParse(productid.Substring(1),out num))
                    {
                        if (num > unqid)
                        {
                            unqid = num;
                        }
                    }
                }
            }

            unqid++; // + 1 / Increment ID for new ID 

            id = $"{firstwrd[0]}{unqid:000}"; // format 

            return id;
        }

        private bool Validate()
        {
            if (string.IsNullOrEmpty(tx_productname.Text) ||
                    cbx_productctg == null ||
                    string.IsNullOrEmpty(tx_productprice.Text) ||
                    string.IsNullOrEmpty(tx_productstock.Text))
            {
                MessageBox.Show("Please fill out all fields","Error",MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            else
            {
                return true;
            }
        }

        private void bt_productadd_Click(object sender, EventArgs e)
        {
            if (Validate())
            {
                string productID = GenerateId();
                dtsave.Rows.Add(productID, tx_productname.Text,tx_productprice.Text,tx_productstock.Text);
            }
        }
        private void ResetField()
        {
            tx_productname.Clear();
            tx_productprice.Clear();
            tx_productstock.Clear();
            cbx_productctg.SelectedItem = null;
        }

        private void bt_productdel_Click(object sender, EventArgs e)
        {
            Validate();
            DataRow row = dtsave.Rows[rowedit];
            dtsave.Rows[rowedit].Delete();
            ResetField();
        }

        private void bt_productedit_Click(object sender, EventArgs e)
        {
            if (Validate())
            {
                DataRow row = dtsave.Rows[rowedit];
                row["Nama"] = tx_productname.Text;
                row["Harga"] = tx_productprice.Text;
                row["Stock Produk"] = tx_productstock.Text;
                row["ID Kategori"] = cbx_productctg.SelectedItem;
            }
            if (string.IsNullOrEmpty(tx_productstock.Text))
            {
                dtsave.Rows[rowedit].Delete();
            }
            ResetField();
        }

        // Category Side
        private string getctgID(string ctgname)
        {
            foreach (DataRow row in dtcategory.Rows)
            {
                if (row["Nama"].ToString() == ctgname)
                {
                    return row["ID"].ToString();
                }
            }
            return null; // not found
        }

        private void productremovectg(string ctgidremove)
        {
            for (int j = dtsave.Rows.Count - 1; j>= 0; j--)
            {
                if (dtsave.Rows[j]["ID Kategori"].ToString() == ctgidremove)
                {
                    dtsave.Rows.RemoveAt(j);
                }
            }
        }

        private void productremovedt(string ctgname)
        {
            for (int k = dtcategory.Rows.Count - 1; k>= 0; k--)
            {
                if (dtcategory.Rows[k]["Nama"].ToString() == ctgname)
                {
                    dtcategory.Rows.RemoveAt(k);
                    return;
                }
            }
            MessageBox.Show("Category not found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }


        private void bt_ctgadd_Click(object sender, EventArgs e)
        {
            string newctg = tx_ctgname.Text;

            if (string.IsNullOrEmpty(newctg)) // check if null
            {
                MessageBox.Show("Please fill out the Category name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            foreach (DataRow dr in dtcategory.Rows) // check if duped
            {
                if (dr["Nama"].ToString() == newctg)
                {
                    MessageBox.Show("Category already exists", "Dupe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            // add category
            string ctgID = $"C{++itemctg}";
            dtcategory.Rows.Add(ctgID,newctg);
            cbx_filter.Items.Add(ctgID);
            cbx_productctg.Items.Add(ctgID);

            tx_ctgname.Clear();
        }
        private void bt_ctgdel_Click(object sender, EventArgs e)
        {
            string ctgname = tx_ctgname.Text.Trim();
            if (string.IsNullOrEmpty(ctgname))
            {
                MessageBox.Show("Please fill out the Category name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string ctgidremove = getctgID(ctgname);
            cbx_productctg.Items.Remove(getctgID(ctgname)); // removes from datagrid view
            productremovectg(ctgidremove); // removes products tied 2 category
            productremovedt(ctgname); // removes from data table
            tx_ctgname.Clear();
        }

        // disables characters from being inputted 2 the boxes
        private void tx_productprice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Only Numbers are allowed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                e. Handled = true;
                return;
            }
        }

        private void tx_productstock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Only Numbers are allowed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                e.Handled = true;
                return;
            }
        }

        private void dtgv_product_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow selectedrow = dtgv_product.Rows[e.RowIndex];
            tx_productname.Text = selectedrow.Cells["Nama"].Value.ToString();
            tx_productprice.Text = selectedrow.Cells["Harga"].Value.ToString();
            tx_productstock.Text = selectedrow.Cells["Stock Produk"].Value.ToString();
            cbx_productctg.SelectedItem = selectedrow.Cells["ID Produk"].Value.ToString() ;

            for (int i = 0; i < dtsave.Rows.Count; i++)
            {
                if (dtsave.Rows[i][1].Equals(tx_productname.Text))
                {
                    rowedit = i;
                    break;
                }
            }
        }

        private void dtgv_ctg_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow selectedrow = dtgv_ctg.Rows[e.RowIndex];
            tx_ctgname.Text = selectedrow.Cells["Nama"].Value.ToString();
        }
    }
}

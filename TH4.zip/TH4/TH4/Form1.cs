﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH4
{
    public partial class Form1 : Form
    {
        string teamName;
        string teamCountry;
        string teamCity;
        string playerName;
        string playerNum;
        string playerRole;
        string teamSelect;

        List<string> Teams = new List<string>();

        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void DisplayTeam()
        {
            lbx_lists.Items.Clear();
            foreach (string team in Teams)
            {
                lbx_lists.Items.Add(team);
            }
        }

        private void bt_teamadd_Click(object sender, EventArgs e)
        {
            teamName = tx_teamname.Text;
            teamCountry = tx_teamcountry.Text;
            teamCity = tx_teamcity.Text;

            if (string.IsNullOrEmpty(teamName) || string.IsNullOrEmpty(teamCountry) || string.IsNullOrEmpty(teamCity))
            {
                MessageBox.Show ("Please fill out the parametes to Add team","Invalid Input",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
            
            if (Teams.Any(Team => teamName.Equals(teamName, StringComparison.OrdinalIgnoreCase)))
            {
                MessageBox.Show("Team already Exists", "Attention", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

        }

        private void bt_playeradd_Click(object sender, EventArgs e)
        {
            playerName = tx_playername.Text;
            playerNum = tx_playernum.Text;
            playerRole = cmb_roles.Text;

            if (string.IsNullOrEmpty(playerName) || string.IsNullOrEmpty(playerNum))
            {
                MessageBox.Show("Please fill out the parametes to Add team", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }
        public class Team
        {
            public string TeamName { get; set; }
            public string TeamCountry { get; set; }
            public string TeamCity { get; set; }
            public List<Player> Players { get; set; }

            public Team(string teamName, string teamCountry, string teamCity)
            {
                TeamName = teamName;
                TeamCountry = teamCountry;
                TeamCity = teamCity;
                Players = new List<Player>();
            }
        }

        public class Player
        {
            public string PlayerName { get; set; }
            public string PlayerNum { get; set; }
            public string PlayerPos { get; set; }

            public Player(string playerName, string playerNum, string playerPos)
            {
                PlayerName = playerName;
                PlayerNum = playerNum;
                PlayerPos = playerPos;
            }
        }
    }
}
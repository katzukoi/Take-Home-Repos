﻿namespace TH4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmb_team = new System.Windows.Forms.ComboBox();
            this.cmb_country = new System.Windows.Forms.ComboBox();
            this.lb_cntry = new System.Windows.Forms.Label();
            this.lb_team = new System.Windows.Forms.Label();
            this.lbx_lists = new System.Windows.Forms.ListBox();
            this.lb_teamadd = new System.Windows.Forms.Label();
            this.lb_nameteam = new System.Windows.Forms.Label();
            this.lb_teamcntry = new System.Windows.Forms.Label();
            this.lb_teamcity = new System.Windows.Forms.Label();
            this.tx_teamname = new System.Windows.Forms.TextBox();
            this.tx_teamcountry = new System.Windows.Forms.TextBox();
            this.tx_teamcity = new System.Windows.Forms.TextBox();
            this.bt_teamadd = new System.Windows.Forms.Button();
            this.bt_playeradd = new System.Windows.Forms.Button();
            this.tx_playernum = new System.Windows.Forms.TextBox();
            this.tx_playername = new System.Windows.Forms.TextBox();
            this.lb_playerrole = new System.Windows.Forms.Label();
            this.lb_playernum = new System.Windows.Forms.Label();
            this.lb_playername = new System.Windows.Forms.Label();
            this.lb_playeradd = new System.Windows.Forms.Label();
            this.cmb_roles = new System.Windows.Forms.ComboBox();
            this.bt_remove = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cmb_team
            // 
            this.cmb_team.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_team.FormattingEnabled = true;
            this.cmb_team.Location = new System.Drawing.Point(91, 110);
            this.cmb_team.Name = "cmb_team";
            this.cmb_team.Size = new System.Drawing.Size(121, 22);
            this.cmb_team.TabIndex = 0;
            // 
            // cmb_country
            // 
            this.cmb_country.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_country.FormattingEnabled = true;
            this.cmb_country.Location = new System.Drawing.Point(91, 61);
            this.cmb_country.Name = "cmb_country";
            this.cmb_country.Size = new System.Drawing.Size(121, 22);
            this.cmb_country.TabIndex = 1;
            // 
            // lb_cntry
            // 
            this.lb_cntry.AutoSize = true;
            this.lb_cntry.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_cntry.Location = new System.Drawing.Point(15, 64);
            this.lb_cntry.Name = "lb_cntry";
            this.lb_cntry.Size = new System.Drawing.Size(70, 14);
            this.lb_cntry.TabIndex = 2;
            this.lb_cntry.Text = "Country :";
            // 
            // lb_team
            // 
            this.lb_team.AutoSize = true;
            this.lb_team.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_team.Location = new System.Drawing.Point(36, 113);
            this.lb_team.Name = "lb_team";
            this.lb_team.Size = new System.Drawing.Size(49, 14);
            this.lb_team.TabIndex = 3;
            this.lb_team.Text = "Team :";
            // 
            // lbx_lists
            // 
            this.lbx_lists.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbx_lists.FormattingEnabled = true;
            this.lbx_lists.ItemHeight = 14;
            this.lbx_lists.Location = new System.Drawing.Point(30, 159);
            this.lbx_lists.Name = "lbx_lists";
            this.lbx_lists.Size = new System.Drawing.Size(182, 116);
            this.lbx_lists.TabIndex = 4;
            // 
            // lb_teamadd
            // 
            this.lb_teamadd.AutoSize = true;
            this.lb_teamadd.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_teamadd.Location = new System.Drawing.Point(281, 25);
            this.lb_teamadd.Name = "lb_teamadd";
            this.lb_teamadd.Size = new System.Drawing.Size(98, 18);
            this.lb_teamadd.TabIndex = 5;
            this.lb_teamadd.Text = "Add Team ";
            // 
            // lb_nameteam
            // 
            this.lb_nameteam.AutoSize = true;
            this.lb_nameteam.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nameteam.Location = new System.Drawing.Point(280, 67);
            this.lb_nameteam.Name = "lb_nameteam";
            this.lb_nameteam.Size = new System.Drawing.Size(84, 14);
            this.lb_nameteam.TabIndex = 8;
            this.lb_nameteam.Text = "Team Name :";
            // 
            // lb_teamcntry
            // 
            this.lb_teamcntry.AutoSize = true;
            this.lb_teamcntry.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_teamcntry.Location = new System.Drawing.Point(260, 110);
            this.lb_teamcntry.Name = "lb_teamcntry";
            this.lb_teamcntry.Size = new System.Drawing.Size(105, 14);
            this.lb_teamcntry.TabIndex = 9;
            this.lb_teamcntry.Text = "Team Country :";
            // 
            // lb_teamcity
            // 
            this.lb_teamcity.AutoSize = true;
            this.lb_teamcity.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_teamcity.Location = new System.Drawing.Point(280, 159);
            this.lb_teamcity.Name = "lb_teamcity";
            this.lb_teamcity.Size = new System.Drawing.Size(84, 14);
            this.lb_teamcity.TabIndex = 10;
            this.lb_teamcity.Text = "Team City :";
            // 
            // tx_teamname
            // 
            this.tx_teamname.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_teamname.Location = new System.Drawing.Point(371, 64);
            this.tx_teamname.Name = "tx_teamname";
            this.tx_teamname.Size = new System.Drawing.Size(100, 20);
            this.tx_teamname.TabIndex = 11;
            // 
            // tx_teamcountry
            // 
            this.tx_teamcountry.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_teamcountry.Location = new System.Drawing.Point(371, 110);
            this.tx_teamcountry.Name = "tx_teamcountry";
            this.tx_teamcountry.Size = new System.Drawing.Size(100, 20);
            this.tx_teamcountry.TabIndex = 12;
            // 
            // tx_teamcity
            // 
            this.tx_teamcity.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_teamcity.Location = new System.Drawing.Point(371, 159);
            this.tx_teamcity.Name = "tx_teamcity";
            this.tx_teamcity.Size = new System.Drawing.Size(100, 20);
            this.tx_teamcity.TabIndex = 13;
            // 
            // bt_teamadd
            // 
            this.bt_teamadd.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_teamadd.Location = new System.Drawing.Point(316, 207);
            this.bt_teamadd.Name = "bt_teamadd";
            this.bt_teamadd.Size = new System.Drawing.Size(118, 47);
            this.bt_teamadd.TabIndex = 14;
            this.bt_teamadd.Text = "Add Team";
            this.bt_teamadd.UseVisualStyleBackColor = true;
            this.bt_teamadd.Click += new System.EventHandler(this.bt_teamadd_Click);
            // 
            // bt_playeradd
            // 
            this.bt_playeradd.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_playeradd.Location = new System.Drawing.Point(561, 207);
            this.bt_playeradd.Name = "bt_playeradd";
            this.bt_playeradd.Size = new System.Drawing.Size(118, 47);
            this.bt_playeradd.TabIndex = 22;
            this.bt_playeradd.Text = "Add Player";
            this.bt_playeradd.UseVisualStyleBackColor = true;
            this.bt_playeradd.Click += new System.EventHandler(this.bt_playeradd_Click);
            // 
            // tx_playernum
            // 
            this.tx_playernum.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_playernum.Location = new System.Drawing.Point(651, 110);
            this.tx_playernum.Name = "tx_playernum";
            this.tx_playernum.Size = new System.Drawing.Size(116, 20);
            this.tx_playernum.TabIndex = 20;
            // 
            // tx_playername
            // 
            this.tx_playername.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_playername.Location = new System.Drawing.Point(651, 64);
            this.tx_playername.Name = "tx_playername";
            this.tx_playername.Size = new System.Drawing.Size(116, 20);
            this.tx_playername.TabIndex = 19;
            // 
            // lb_playerrole
            // 
            this.lb_playerrole.AutoSize = true;
            this.lb_playerrole.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_playerrole.Location = new System.Drawing.Point(545, 159);
            this.lb_playerrole.Name = "lb_playerrole";
            this.lb_playerrole.Size = new System.Drawing.Size(98, 14);
            this.lb_playerrole.TabIndex = 18;
            this.lb_playerrole.Text = "Player Role :";
            // 
            // lb_playernum
            // 
            this.lb_playernum.AutoSize = true;
            this.lb_playernum.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_playernum.Location = new System.Drawing.Point(532, 110);
            this.lb_playernum.Name = "lb_playernum";
            this.lb_playernum.Size = new System.Drawing.Size(112, 14);
            this.lb_playernum.TabIndex = 17;
            this.lb_playernum.Text = "Player Number :";
            // 
            // lb_playername
            // 
            this.lb_playername.AutoSize = true;
            this.lb_playername.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_playername.Location = new System.Drawing.Point(545, 67);
            this.lb_playername.Name = "lb_playername";
            this.lb_playername.Size = new System.Drawing.Size(98, 14);
            this.lb_playername.TabIndex = 16;
            this.lb_playername.Text = "Player Name :";
            // 
            // lb_playeradd
            // 
            this.lb_playeradd.AutoSize = true;
            this.lb_playeradd.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_playeradd.Location = new System.Drawing.Point(526, 25);
            this.lb_playeradd.Name = "lb_playeradd";
            this.lb_playeradd.Size = new System.Drawing.Size(118, 18);
            this.lb_playeradd.TabIndex = 15;
            this.lb_playeradd.Text = "Add Player ";
            // 
            // cmb_roles
            // 
            this.cmb_roles.FormattingEnabled = true;
            this.cmb_roles.Location = new System.Drawing.Point(650, 157);
            this.cmb_roles.Name = "cmb_roles";
            this.cmb_roles.Size = new System.Drawing.Size(116, 21);
            this.cmb_roles.TabIndex = 23;
            // 
            // bt_remove
            // 
            this.bt_remove.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_remove.Location = new System.Drawing.Point(30, 281);
            this.bt_remove.Name = "bt_remove";
            this.bt_remove.Size = new System.Drawing.Size(75, 23);
            this.bt_remove.TabIndex = 24;
            this.bt_remove.Text = "Remove";
            this.bt_remove.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bt_remove);
            this.Controls.Add(this.cmb_roles);
            this.Controls.Add(this.bt_playeradd);
            this.Controls.Add(this.tx_playernum);
            this.Controls.Add(this.tx_playername);
            this.Controls.Add(this.lb_playerrole);
            this.Controls.Add(this.lb_playernum);
            this.Controls.Add(this.lb_playername);
            this.Controls.Add(this.lb_playeradd);
            this.Controls.Add(this.bt_teamadd);
            this.Controls.Add(this.tx_teamcity);
            this.Controls.Add(this.tx_teamcountry);
            this.Controls.Add(this.tx_teamname);
            this.Controls.Add(this.lb_teamcity);
            this.Controls.Add(this.lb_teamcntry);
            this.Controls.Add(this.lb_nameteam);
            this.Controls.Add(this.lb_teamadd);
            this.Controls.Add(this.lbx_lists);
            this.Controls.Add(this.lb_team);
            this.Controls.Add(this.lb_cntry);
            this.Controls.Add(this.cmb_country);
            this.Controls.Add(this.cmb_team);
            this.Name = "Form1";
            this.Text = "FutBall";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmb_team;
        private System.Windows.Forms.ComboBox cmb_country;
        private System.Windows.Forms.Label lb_cntry;
        private System.Windows.Forms.Label lb_team;
        private System.Windows.Forms.ListBox lbx_lists;
        private System.Windows.Forms.Label lb_teamadd;
        private System.Windows.Forms.Label lb_nameteam;
        private System.Windows.Forms.Label lb_teamcntry;
        private System.Windows.Forms.Label lb_teamcity;
        private System.Windows.Forms.TextBox tx_teamname;
        private System.Windows.Forms.TextBox tx_teamcountry;
        private System.Windows.Forms.TextBox tx_teamcity;
        private System.Windows.Forms.Button bt_teamadd;
        private System.Windows.Forms.Button bt_playeradd;
        private System.Windows.Forms.TextBox tx_playernum;
        private System.Windows.Forms.TextBox tx_playername;
        private System.Windows.Forms.Label lb_playerrole;
        private System.Windows.Forms.Label lb_playernum;
        private System.Windows.Forms.Label lb_playername;
        private System.Windows.Forms.Label lb_playeradd;
        private System.Windows.Forms.ComboBox cmb_roles;
        private System.Windows.Forms.Button bt_remove;
    }
}


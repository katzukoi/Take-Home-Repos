﻿namespace TH3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_ucbank = new System.Windows.Forms.Label();
            this.pnl_reg = new System.Windows.Forms.Panel();
            this.bt_register = new System.Windows.Forms.Button();
            this.tx_regpassinpt = new System.Windows.Forms.TextBox();
            this.tx_regusrinpt = new System.Windows.Forms.TextBox();
            this.lb_regpass = new System.Windows.Forms.Label();
            this.lb_regusr = new System.Windows.Forms.Label();
            this.pnl_main = new System.Windows.Forms.Panel();
            this.lb__mainbalancecount = new System.Windows.Forms.Label();
            this.bt_withdrw = new System.Windows.Forms.Button();
            this.bt_depo = new System.Windows.Forms.Button();
            this.lb_mainbalance = new System.Windows.Forms.Label();
            this.bt_mainlogout = new System.Windows.Forms.Button();
            this.pnl_deposcreen = new System.Windows.Forms.Panel();
            this.tx_depoinpt = new System.Windows.Forms.TextBox();
            this.lb_depoinfo = new System.Windows.Forms.Label();
            this.bt_fundepo = new System.Windows.Forms.Button();
            this.lb_depo = new System.Windows.Forms.Label();
            this.bt_depologout = new System.Windows.Forms.Button();
            this.pnl_wthdrwscreen = new System.Windows.Forms.Panel();
            this.tx_wthdrwinpt = new System.Windows.Forms.TextBox();
            this.lb_wthdrwinfo = new System.Windows.Forms.Label();
            this.bt_fundwthdrw = new System.Windows.Forms.Button();
            this.lb_wthdrw = new System.Windows.Forms.Label();
            this.bt_wthdralogout = new System.Windows.Forms.Button();
            this.pnl_logreg = new System.Windows.Forms.Panel();
            this.lb_reginfo = new System.Windows.Forms.Label();
            this.bt_login = new System.Windows.Forms.Button();
            this.bt_logregister = new System.Windows.Forms.Button();
            this.tx_logpassinpt = new System.Windows.Forms.TextBox();
            this.tx_logusrinpt = new System.Windows.Forms.TextBox();
            this.lb_logpass = new System.Windows.Forms.Label();
            this.lb_logusr = new System.Windows.Forms.Label();
            this.pnl_reg.SuspendLayout();
            this.pnl_main.SuspendLayout();
            this.pnl_deposcreen.SuspendLayout();
            this.pnl_wthdrwscreen.SuspendLayout();
            this.pnl_logreg.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_ucbank
            // 
            this.lb_ucbank.AutoSize = true;
            this.lb_ucbank.Font = new System.Drawing.Font("Courier New", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ucbank.Location = new System.Drawing.Point(72, 30);
            this.lb_ucbank.Name = "lb_ucbank";
            this.lb_ucbank.Size = new System.Drawing.Size(134, 33);
            this.lb_ucbank.TabIndex = 0;
            this.lb_ucbank.Text = "UC Bank";
            // 
            // pnl_reg
            // 
            this.pnl_reg.Controls.Add(this.bt_register);
            this.pnl_reg.Controls.Add(this.tx_regpassinpt);
            this.pnl_reg.Controls.Add(this.tx_regusrinpt);
            this.pnl_reg.Controls.Add(this.lb_regpass);
            this.pnl_reg.Controls.Add(this.lb_regusr);
            this.pnl_reg.Location = new System.Drawing.Point(48, 66);
            this.pnl_reg.Name = "pnl_reg";
            this.pnl_reg.Size = new System.Drawing.Size(174, 155);
            this.pnl_reg.TabIndex = 1;
            // 
            // bt_register
            // 
            this.bt_register.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_register.Location = new System.Drawing.Point(49, 88);
            this.bt_register.Name = "bt_register";
            this.bt_register.Size = new System.Drawing.Size(75, 23);
            this.bt_register.TabIndex = 4;
            this.bt_register.Text = "Register";
            this.bt_register.UseVisualStyleBackColor = true;
            this.bt_register.Click += new System.EventHandler(this.bt_register_Click);
            // 
            // tx_regpassinpt
            // 
            this.tx_regpassinpt.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_regpassinpt.Location = new System.Drawing.Point(66, 52);
            this.tx_regpassinpt.Name = "tx_regpassinpt";
            this.tx_regpassinpt.Size = new System.Drawing.Size(100, 20);
            this.tx_regpassinpt.TabIndex = 3;
            // 
            // tx_regusrinpt
            // 
            this.tx_regusrinpt.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_regusrinpt.Location = new System.Drawing.Point(66, 23);
            this.tx_regusrinpt.Name = "tx_regusrinpt";
            this.tx_regusrinpt.Size = new System.Drawing.Size(100, 20);
            this.tx_regusrinpt.TabIndex = 2;
            // 
            // lb_regpass
            // 
            this.lb_regpass.AutoSize = true;
            this.lb_regpass.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_regpass.Location = new System.Drawing.Point(11, 52);
            this.lb_regpass.Name = "lb_regpass";
            this.lb_regpass.Size = new System.Drawing.Size(49, 14);
            this.lb_regpass.TabIndex = 1;
            this.lb_regpass.Text = "pass :";
            // 
            // lb_regusr
            // 
            this.lb_regusr.AutoSize = true;
            this.lb_regusr.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_regusr.Location = new System.Drawing.Point(11, 26);
            this.lb_regusr.Name = "lb_regusr";
            this.lb_regusr.Size = new System.Drawing.Size(49, 14);
            this.lb_regusr.TabIndex = 0;
            this.lb_regusr.Text = "user :";
            // 
            // pnl_main
            // 
            this.pnl_main.Controls.Add(this.lb__mainbalancecount);
            this.pnl_main.Controls.Add(this.bt_withdrw);
            this.pnl_main.Controls.Add(this.bt_depo);
            this.pnl_main.Controls.Add(this.lb_mainbalance);
            this.pnl_main.Controls.Add(this.bt_mainlogout);
            this.pnl_main.Location = new System.Drawing.Point(48, 66);
            this.pnl_main.Name = "pnl_main";
            this.pnl_main.Size = new System.Drawing.Size(174, 155);
            this.pnl_main.TabIndex = 2;
            this.pnl_main.Visible = false;
            // 
            // lb__mainbalancecount
            // 
            this.lb__mainbalancecount.AutoSize = true;
            this.lb__mainbalancecount.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb__mainbalancecount.Location = new System.Drawing.Point(61, 38);
            this.lb__mainbalancecount.Name = "lb__mainbalancecount";
            this.lb__mainbalancecount.Size = new System.Drawing.Size(28, 14);
            this.lb__mainbalancecount.TabIndex = 4;
            this.lb__mainbalancecount.Text = "---";
            // 
            // bt_withdrw
            // 
            this.bt_withdrw.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_withdrw.Location = new System.Drawing.Point(47, 94);
            this.bt_withdrw.Name = "bt_withdrw";
            this.bt_withdrw.Size = new System.Drawing.Size(75, 23);
            this.bt_withdrw.TabIndex = 3;
            this.bt_withdrw.Text = "Withdraw";
            this.bt_withdrw.UseVisualStyleBackColor = true;
            this.bt_withdrw.Click += new System.EventHandler(this.bt_withdrw_Click);
            // 
            // bt_depo
            // 
            this.bt_depo.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_depo.Location = new System.Drawing.Point(47, 65);
            this.bt_depo.Name = "bt_depo";
            this.bt_depo.Size = new System.Drawing.Size(75, 23);
            this.bt_depo.TabIndex = 2;
            this.bt_depo.Text = "Deposit";
            this.bt_depo.UseVisualStyleBackColor = true;
            this.bt_depo.Click += new System.EventHandler(this.bt_depo_Click);
            // 
            // lb_mainbalance
            // 
            this.lb_mainbalance.AutoSize = true;
            this.lb_mainbalance.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_mainbalance.Location = new System.Drawing.Point(52, 10);
            this.lb_mainbalance.Name = "lb_mainbalance";
            this.lb_mainbalance.Size = new System.Drawing.Size(70, 14);
            this.lb_mainbalance.TabIndex = 1;
            this.lb_mainbalance.Text = "Balance :";
            // 
            // bt_mainlogout
            // 
            this.bt_mainlogout.Location = new System.Drawing.Point(3, 132);
            this.bt_mainlogout.Name = "bt_mainlogout";
            this.bt_mainlogout.Size = new System.Drawing.Size(53, 20);
            this.bt_mainlogout.TabIndex = 0;
            this.bt_mainlogout.Text = "Log out";
            this.bt_mainlogout.UseVisualStyleBackColor = true;
            this.bt_mainlogout.Click += new System.EventHandler(this.bt_mainlogout_Click);
            // 
            // pnl_deposcreen
            // 
            this.pnl_deposcreen.Controls.Add(this.tx_depoinpt);
            this.pnl_deposcreen.Controls.Add(this.lb_depoinfo);
            this.pnl_deposcreen.Controls.Add(this.bt_fundepo);
            this.pnl_deposcreen.Controls.Add(this.lb_depo);
            this.pnl_deposcreen.Controls.Add(this.bt_depologout);
            this.pnl_deposcreen.Location = new System.Drawing.Point(48, 66);
            this.pnl_deposcreen.Name = "pnl_deposcreen";
            this.pnl_deposcreen.Size = new System.Drawing.Size(174, 155);
            this.pnl_deposcreen.TabIndex = 5;
            this.pnl_deposcreen.Visible = false;
            // 
            // tx_depoinpt
            // 
            this.tx_depoinpt.Location = new System.Drawing.Point(33, 68);
            this.tx_depoinpt.Name = "tx_depoinpt";
            this.tx_depoinpt.Size = new System.Drawing.Size(100, 20);
            this.tx_depoinpt.TabIndex = 5;
            // 
            // lb_depoinfo
            // 
            this.lb_depoinfo.AutoSize = true;
            this.lb_depoinfo.Font = new System.Drawing.Font("Courier New", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_depoinfo.Location = new System.Drawing.Point(22, 52);
            this.lb_depoinfo.Name = "lb_depoinfo";
            this.lb_depoinfo.Size = new System.Drawing.Size(120, 12);
            this.lb_depoinfo.TabIndex = 4;
            this.lb_depoinfo.Text = "Insert Deposit Amount :";
            // 
            // bt_fundepo
            // 
            this.bt_fundepo.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_fundepo.Location = new System.Drawing.Point(47, 94);
            this.bt_fundepo.Name = "bt_fundepo";
            this.bt_fundepo.Size = new System.Drawing.Size(75, 23);
            this.bt_fundepo.TabIndex = 3;
            this.bt_fundepo.Text = "Deposit";
            this.bt_fundepo.UseVisualStyleBackColor = true;
            this.bt_fundepo.Click += new System.EventHandler(this.bt_fundepo_Click);
            // 
            // lb_depo
            // 
            this.lb_depo.AutoSize = true;
            this.lb_depo.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_depo.Location = new System.Drawing.Point(35, 10);
            this.lb_depo.Name = "lb_depo";
            this.lb_depo.Size = new System.Drawing.Size(98, 14);
            this.lb_depo.TabIndex = 1;
            this.lb_depo.Text = "Deposit Funds";
            // 
            // bt_depologout
            // 
            this.bt_depologout.Location = new System.Drawing.Point(3, 132);
            this.bt_depologout.Name = "bt_depologout";
            this.bt_depologout.Size = new System.Drawing.Size(53, 20);
            this.bt_depologout.TabIndex = 0;
            this.bt_depologout.Text = "Log out";
            this.bt_depologout.UseVisualStyleBackColor = true;
            this.bt_depologout.Click += new System.EventHandler(this.bt_depologout_Click);
            // 
            // pnl_wthdrwscreen
            // 
            this.pnl_wthdrwscreen.Controls.Add(this.tx_wthdrwinpt);
            this.pnl_wthdrwscreen.Controls.Add(this.lb_wthdrwinfo);
            this.pnl_wthdrwscreen.Controls.Add(this.bt_fundwthdrw);
            this.pnl_wthdrwscreen.Controls.Add(this.lb_wthdrw);
            this.pnl_wthdrwscreen.Controls.Add(this.bt_wthdralogout);
            this.pnl_wthdrwscreen.Location = new System.Drawing.Point(3, 0);
            this.pnl_wthdrwscreen.Name = "pnl_wthdrwscreen";
            this.pnl_wthdrwscreen.Size = new System.Drawing.Size(174, 155);
            this.pnl_wthdrwscreen.TabIndex = 6;
            this.pnl_wthdrwscreen.Visible = false;
            // 
            // tx_wthdrwinpt
            // 
            this.tx_wthdrwinpt.Location = new System.Drawing.Point(33, 68);
            this.tx_wthdrwinpt.Name = "tx_wthdrwinpt";
            this.tx_wthdrwinpt.Size = new System.Drawing.Size(100, 20);
            this.tx_wthdrwinpt.TabIndex = 5;
            // 
            // lb_wthdrwinfo
            // 
            this.lb_wthdrwinfo.AutoSize = true;
            this.lb_wthdrwinfo.Font = new System.Drawing.Font("Courier New", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_wthdrwinfo.Location = new System.Drawing.Point(31, 52);
            this.lb_wthdrwinfo.Name = "lb_wthdrwinfo";
            this.lb_wthdrwinfo.Size = new System.Drawing.Size(125, 12);
            this.lb_wthdrwinfo.TabIndex = 4;
            this.lb_wthdrwinfo.Text = "Insert Withdraw Amount :";
            // 
            // bt_fundwthdrw
            // 
            this.bt_fundwthdrw.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_fundwthdrw.Location = new System.Drawing.Point(47, 94);
            this.bt_fundwthdrw.Name = "bt_fundwthdrw";
            this.bt_fundwthdrw.Size = new System.Drawing.Size(75, 23);
            this.bt_fundwthdrw.TabIndex = 3;
            this.bt_fundwthdrw.Text = "Withdraw";
            this.bt_fundwthdrw.UseVisualStyleBackColor = true;
            this.bt_fundwthdrw.Click += new System.EventHandler(this.bt_fundwthdrw_Click);
            // 
            // lb_wthdrw
            // 
            this.lb_wthdrw.AutoSize = true;
            this.lb_wthdrw.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_wthdrw.Location = new System.Drawing.Point(35, 10);
            this.lb_wthdrw.Name = "lb_wthdrw";
            this.lb_wthdrw.Size = new System.Drawing.Size(105, 14);
            this.lb_wthdrw.TabIndex = 1;
            this.lb_wthdrw.Text = "Withdraw Funds";
            // 
            // bt_wthdralogout
            // 
            this.bt_wthdralogout.Location = new System.Drawing.Point(3, 132);
            this.bt_wthdralogout.Name = "bt_wthdralogout";
            this.bt_wthdralogout.Size = new System.Drawing.Size(53, 20);
            this.bt_wthdralogout.TabIndex = 0;
            this.bt_wthdralogout.Text = "Log out";
            this.bt_wthdralogout.UseVisualStyleBackColor = true;
            this.bt_wthdralogout.Click += new System.EventHandler(this.bt_wthdralogout_Click);
            // 
            // pnl_logreg
            // 
            this.pnl_logreg.Controls.Add(this.lb_reginfo);
            this.pnl_logreg.Controls.Add(this.pnl_wthdrwscreen);
            this.pnl_logreg.Controls.Add(this.bt_login);
            this.pnl_logreg.Controls.Add(this.bt_logregister);
            this.pnl_logreg.Controls.Add(this.tx_logpassinpt);
            this.pnl_logreg.Controls.Add(this.tx_logusrinpt);
            this.pnl_logreg.Controls.Add(this.lb_logpass);
            this.pnl_logreg.Controls.Add(this.lb_logusr);
            this.pnl_logreg.Location = new System.Drawing.Point(48, 66);
            this.pnl_logreg.Name = "pnl_logreg";
            this.pnl_logreg.Size = new System.Drawing.Size(174, 201);
            this.pnl_logreg.TabIndex = 6;
            this.pnl_logreg.Visible = false;
            // 
            // lb_reginfo
            // 
            this.lb_reginfo.AutoSize = true;
            this.lb_reginfo.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_reginfo.Location = new System.Drawing.Point(18, 158);
            this.lb_reginfo.Name = "lb_reginfo";
            this.lb_reginfo.Size = new System.Drawing.Size(140, 14);
            this.lb_reginfo.TabIndex = 6;
            this.lb_reginfo.Text = "No Account? Sign Up";
            // 
            // bt_login
            // 
            this.bt_login.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_login.Location = new System.Drawing.Point(49, 88);
            this.bt_login.Name = "bt_login";
            this.bt_login.Size = new System.Drawing.Size(75, 23);
            this.bt_login.TabIndex = 5;
            this.bt_login.Text = "Login";
            this.bt_login.UseVisualStyleBackColor = true;
            this.bt_login.Click += new System.EventHandler(this.bt_login_Click);
            // 
            // bt_logregister
            // 
            this.bt_logregister.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_logregister.Location = new System.Drawing.Point(49, 175);
            this.bt_logregister.Name = "bt_logregister";
            this.bt_logregister.Size = new System.Drawing.Size(75, 23);
            this.bt_logregister.TabIndex = 4;
            this.bt_logregister.Text = "Register";
            this.bt_logregister.UseVisualStyleBackColor = true;
            this.bt_logregister.Click += new System.EventHandler(this.bt_logregister_Click);
            // 
            // tx_logpassinpt
            // 
            this.tx_logpassinpt.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_logpassinpt.Location = new System.Drawing.Point(66, 52);
            this.tx_logpassinpt.Name = "tx_logpassinpt";
            this.tx_logpassinpt.Size = new System.Drawing.Size(100, 20);
            this.tx_logpassinpt.TabIndex = 3;
            // 
            // tx_logusrinpt
            // 
            this.tx_logusrinpt.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_logusrinpt.Location = new System.Drawing.Point(66, 23);
            this.tx_logusrinpt.Name = "tx_logusrinpt";
            this.tx_logusrinpt.Size = new System.Drawing.Size(100, 20);
            this.tx_logusrinpt.TabIndex = 2;
            // 
            // lb_logpass
            // 
            this.lb_logpass.AutoSize = true;
            this.lb_logpass.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_logpass.Location = new System.Drawing.Point(11, 52);
            this.lb_logpass.Name = "lb_logpass";
            this.lb_logpass.Size = new System.Drawing.Size(49, 14);
            this.lb_logpass.TabIndex = 1;
            this.lb_logpass.Text = "pass :";
            // 
            // lb_logusr
            // 
            this.lb_logusr.AutoSize = true;
            this.lb_logusr.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_logusr.Location = new System.Drawing.Point(11, 26);
            this.lb_logusr.Name = "lb_logusr";
            this.lb_logusr.Size = new System.Drawing.Size(49, 14);
            this.lb_logusr.TabIndex = 0;
            this.lb_logusr.Text = "user :";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(832, 450);
            this.Controls.Add(this.pnl_logreg);
            this.Controls.Add(this.pnl_deposcreen);
            this.Controls.Add(this.pnl_main);
            this.Controls.Add(this.pnl_reg);
            this.Controls.Add(this.lb_ucbank);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pnl_reg.ResumeLayout(false);
            this.pnl_reg.PerformLayout();
            this.pnl_main.ResumeLayout(false);
            this.pnl_main.PerformLayout();
            this.pnl_deposcreen.ResumeLayout(false);
            this.pnl_deposcreen.PerformLayout();
            this.pnl_wthdrwscreen.ResumeLayout(false);
            this.pnl_wthdrwscreen.PerformLayout();
            this.pnl_logreg.ResumeLayout(false);
            this.pnl_logreg.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_ucbank;
        private System.Windows.Forms.Panel pnl_reg;
        private System.Windows.Forms.TextBox tx_regpassinpt;
        private System.Windows.Forms.TextBox tx_regusrinpt;
        private System.Windows.Forms.Label lb_regpass;
        private System.Windows.Forms.Label lb_regusr;
        private System.Windows.Forms.Button bt_register;
        private System.Windows.Forms.Panel pnl_main;
        private System.Windows.Forms.Button bt_mainlogout;
        private System.Windows.Forms.Label lb__mainbalancecount;
        private System.Windows.Forms.Button bt_withdrw;
        private System.Windows.Forms.Button bt_depo;
        private System.Windows.Forms.Label lb_mainbalance;
        private System.Windows.Forms.Panel pnl_deposcreen;
        private System.Windows.Forms.Label lb_depoinfo;
        private System.Windows.Forms.Button bt_fundepo;
        private System.Windows.Forms.Label lb_depo;
        private System.Windows.Forms.Button bt_depologout;
        private System.Windows.Forms.TextBox tx_depoinpt;
        private System.Windows.Forms.Panel pnl_wthdrwscreen;
        private System.Windows.Forms.TextBox tx_wthdrwinpt;
        private System.Windows.Forms.Label lb_wthdrwinfo;
        private System.Windows.Forms.Button bt_fundwthdrw;
        private System.Windows.Forms.Label lb_wthdrw;
        private System.Windows.Forms.Button bt_wthdralogout;
        private System.Windows.Forms.Panel pnl_logreg;
        private System.Windows.Forms.Button bt_login;
        private System.Windows.Forms.Button bt_logregister;
        private System.Windows.Forms.TextBox tx_logpassinpt;
        private System.Windows.Forms.TextBox tx_logusrinpt;
        private System.Windows.Forms.Label lb_logpass;
        private System.Windows.Forms.Label lb_logusr;
        private System.Windows.Forms.Label lb_reginfo;
    }
}


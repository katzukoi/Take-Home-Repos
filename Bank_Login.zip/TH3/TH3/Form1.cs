﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH3
{
    public partial class Form1 : Form
    {

        public Dictionary<string, string> credentials = new Dictionary<string , string>();
        public Dictionary<string, string> balance = new Dictionary<string , string>();
        public string screenbalance;
        public string usrname;
        public string usrpass;

        public Form1()
        {
            InitializeComponent();
        }

        private void bt_register_Click(object sender, EventArgs e)
        {
            usrname = tx_regusrinpt.Text;
            usrpass = tx_regpassinpt.Text;

            //null check usrname & pass
            if (string.IsNullOrEmpty(usrname) || string.IsNullOrEmpty(usrpass))
            {
                MessageBox.Show("username dan password wajib diisi");
                return;
            }
            //usrname check duplikat
            if (credentials.ContainsKey(usrname))
            {
                MessageBox.Show("Username telah digunakan, silahkan mencoba lagi");
                return;
            }
            else
            {
                //add usrname + balance to dictionary
                credentials.Add(usrname, usrpass);
                balance.Add(usrname, "0");
                MessageBox.Show("Akun berhasil dibuat");
                tx_regusrinpt.Clear();
                tx_regpassinpt.Clear();
                pnl_reg.Visible = false;
                pnl_logreg.Visible = true;
            }
        }

        private void bt_login_Click(object sender, EventArgs e)
        {
            usrname = tx_logusrinpt.Text;
            usrpass = tx_logpassinpt.Text;

            //null check
            if (string.IsNullOrEmpty(usrname) || string.IsNullOrEmpty(usrpass))
            {
                MessageBox.Show("username dan password wajib diisi");
                return;
            }
            //existing account check
            if (credentials.ContainsKey(usrname))
            {
                //pass of account check
                if (credentials[usrname] == usrpass)
                {
                    MessageBox.Show("Login Berhasil, Selamat Datang");
                    screenbalance = string.Format("{0:#,0}", balance[usrname]).Replace(",", ".");
                    lb__mainbalancecount.Text = "Rp" + screenbalance + ",00";
                    tx_logusrinpt.Clear();
                    tx_logpassinpt.Clear();
                    pnl_logreg.Visible = false;
                    pnl_main.Visible = true;
                }
                else
                {
                    MessageBox.Show("Password salah, silahkan coba lagi");
                }
            }
            else
            {
                MessageBox.Show("Akun tidak ditemukan, silahkan coba lagi");
            }
        }
        //depo panel view
        private void bt_depo_Click(object sender, EventArgs e)
        {
            pnl_deposcreen.Visible = true;
            pnl_main.Visible = false;

        }
        //withdraw panel view
        private void bt_withdrw_Click(object sender, EventArgs e)
        {
            pnl_wthdrwscreen.Visible = true;
            pnl_main.Visible = false;
        }

        private void bt_fundepo_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tx_depoinpt.Text))
            {
                MessageBox.Show("jumlah deposit belum terisi");
                return;
            }
            else
            {
                int depinptamount = int.Parse(tx_depoinpt.Text);
                int balancenow= int.Parse(balance[usrname]);
                //cek jumlah depo
                if (depinptamount > 0)
                {
                    balancenow += depinptamount;
                    balance[usrname] = balancenow.ToString();
                    screenbalance = string.Format("{0:#,0}", balance[usrname]).Replace(",", ".");
                    lb__mainbalancecount.Text = "Rp" + screenbalance + ",00";
                    MessageBox.Show("Deposit saldo berhasil!");
                    tx_depoinpt.Clear();
                    pnl_main.Visible = true;
                    pnl_deposcreen.Visible = false;
                }
                else if (depinptamount < 1)
                {
                    MessageBox.Show("jumlah deposit tidak boleh kurang dari 1");
                }
            }
        }

        private void bt_fundwthdrw_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tx_wthdrwinpt.Text))
            {
                MessageBox.Show("jumlah withdraw belum terisi");
                return;
            }
            else
            {
                int wthdrwamount = int.Parse(tx_wthdrwinpt.Text);
                int balancenow = int.Parse(balance[usrname]);

                if (wthdrwamount > 0)
                {
                    balancenow -= wthdrwamount;
                    balance[usrname] = balancenow.ToString();
                    screenbalance = string.Format("{0:#,0}", balance[usrname]).Replace(",", ".");
                    lb__mainbalancecount.Text = "Rp" + screenbalance + ",00";
                    MessageBox.Show("Withdrawal saldo berhasil!");
                    tx_wthdrwinpt.Clear();
                    pnl_main.Visible = true;
                    pnl_wthdrwscreen.Visible = false;
                }
                else if (wthdrwamount < 1)
                {
                    MessageBox.Show("jumlah withdraw tidak boleh kurang dari 1");
                }
            }
        }

        //logout buttons
        private void bt_logregister_Click(object sender, EventArgs e)
        {
            pnl_logreg.Visible = false;
            pnl_reg.Visible = true;
        }

        private void bt_mainlogout_Click(object sender, EventArgs e)
        {
            pnl_main.Visible = false;
            pnl_logreg.Visible = true;
        }

        private void bt_depologout_Click(object sender, EventArgs e)
        {
            pnl_deposcreen.Visible = false;
            pnl_logreg.Visible = true;
        }

        private void bt_wthdralogout_Click(object sender, EventArgs e)
        {
            pnl_wthdrwscreen.Visible = false;
            pnl_logreg.Visible = true;
        }

        
    }
}

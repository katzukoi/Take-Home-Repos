﻿namespace th9
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtgv_shelf = new System.Windows.Forms.DataGridView();
            this.tx_totalprc = new System.Windows.Forms.TextBox();
            this.tx_subtotalprc = new System.Windows.Forms.TextBox();
            this.lb_totalinfo = new System.Windows.Forms.Label();
            this.lb_subtotalinfo = new System.Windows.Forms.Label();
            this.pb_menuupload = new System.Windows.Forms.PictureBox();
            this.bt_addcart1 = new System.Windows.Forms.Button();
            this.tx_itemname = new System.Windows.Forms.TextBox();
            this.tx_itemprice = new System.Windows.Forms.TextBox();
            this.bt_pbupload = new System.Windows.Forms.Button();
            this.lb_uploadinfo = new System.Windows.Forms.Label();
            this.lb_cstmname = new System.Windows.Forms.Label();
            this.lb_cstmprice = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_shelf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_menuupload)).BeginInit();
            this.SuspendLayout();
            // 
            // dtgv_shelf
            // 
            this.dtgv_shelf.AllowUserToAddRows = false;
            this.dtgv_shelf.AllowUserToDeleteRows = false;
            this.dtgv_shelf.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_shelf.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtgv_shelf.Location = new System.Drawing.Point(344, 12);
            this.dtgv_shelf.Name = "dtgv_shelf";
            this.dtgv_shelf.Size = new System.Drawing.Size(314, 280);
            this.dtgv_shelf.TabIndex = 2;
            // 
            // tx_totalprc
            // 
            this.tx_totalprc.Location = new System.Drawing.Point(473, 337);
            this.tx_totalprc.Name = "tx_totalprc";
            this.tx_totalprc.Size = new System.Drawing.Size(100, 20);
            this.tx_totalprc.TabIndex = 9;
            // 
            // tx_subtotalprc
            // 
            this.tx_subtotalprc.Location = new System.Drawing.Point(473, 311);
            this.tx_subtotalprc.Name = "tx_subtotalprc";
            this.tx_subtotalprc.Size = new System.Drawing.Size(100, 20);
            this.tx_subtotalprc.TabIndex = 8;
            // 
            // lb_totalinfo
            // 
            this.lb_totalinfo.AutoSize = true;
            this.lb_totalinfo.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_totalinfo.Location = new System.Drawing.Point(384, 335);
            this.lb_totalinfo.Name = "lb_totalinfo";
            this.lb_totalinfo.Size = new System.Drawing.Size(87, 22);
            this.lb_totalinfo.TabIndex = 7;
            this.lb_totalinfo.Text = "Total :";
            // 
            // lb_subtotalinfo
            // 
            this.lb_subtotalinfo.AutoSize = true;
            this.lb_subtotalinfo.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_subtotalinfo.Location = new System.Drawing.Point(340, 311);
            this.lb_subtotalinfo.Name = "lb_subtotalinfo";
            this.lb_subtotalinfo.Size = new System.Drawing.Size(131, 22);
            this.lb_subtotalinfo.TabIndex = 6;
            this.lb_subtotalinfo.Text = "Sub-Total :";
            // 
            // pb_menuupload
            // 
            this.pb_menuupload.Location = new System.Drawing.Point(12, 55);
            this.pb_menuupload.Name = "pb_menuupload";
            this.pb_menuupload.Size = new System.Drawing.Size(113, 237);
            this.pb_menuupload.TabIndex = 10;
            this.pb_menuupload.TabStop = false;
            // 
            // bt_addcart1
            // 
            this.bt_addcart1.Location = new System.Drawing.Point(236, 269);
            this.bt_addcart1.Name = "bt_addcart1";
            this.bt_addcart1.Size = new System.Drawing.Size(75, 23);
            this.bt_addcart1.TabIndex = 16;
            this.bt_addcart1.Text = "Add 2 Cart";
            this.bt_addcart1.UseVisualStyleBackColor = true;
            this.bt_addcart1.Click += new System.EventHandler(this.bt_addcart1_Click);
            // 
            // tx_itemname
            // 
            this.tx_itemname.Location = new System.Drawing.Point(211, 213);
            this.tx_itemname.Name = "tx_itemname";
            this.tx_itemname.Size = new System.Drawing.Size(100, 20);
            this.tx_itemname.TabIndex = 17;
            // 
            // tx_itemprice
            // 
            this.tx_itemprice.Location = new System.Drawing.Point(211, 239);
            this.tx_itemprice.Name = "tx_itemprice";
            this.tx_itemprice.Size = new System.Drawing.Size(100, 20);
            this.tx_itemprice.TabIndex = 18;
            this.tx_itemprice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_itemprice_KeyPress);
            // 
            // bt_pbupload
            // 
            this.bt_pbupload.Location = new System.Drawing.Point(236, 68);
            this.bt_pbupload.Name = "bt_pbupload";
            this.bt_pbupload.Size = new System.Drawing.Size(75, 23);
            this.bt_pbupload.TabIndex = 19;
            this.bt_pbupload.Text = "Upload";
            this.bt_pbupload.UseVisualStyleBackColor = true;
            this.bt_pbupload.Click += new System.EventHandler(this.bt_pbupload_Click);
            // 
            // lb_uploadinfo
            // 
            this.lb_uploadinfo.AutoSize = true;
            this.lb_uploadinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_uploadinfo.Location = new System.Drawing.Point(136, 71);
            this.lb_uploadinfo.Name = "lb_uploadinfo";
            this.lb_uploadinfo.Size = new System.Drawing.Size(94, 15);
            this.lb_uploadinfo.TabIndex = 20;
            this.lb_uploadinfo.Text = "Upload Picture :";
            // 
            // lb_cstmname
            // 
            this.lb_cstmname.AutoSize = true;
            this.lb_cstmname.Location = new System.Drawing.Point(139, 219);
            this.lb_cstmname.Name = "lb_cstmname";
            this.lb_cstmname.Size = new System.Drawing.Size(64, 13);
            this.lb_cstmname.TabIndex = 21;
            this.lb_cstmname.Text = "Item Name :";
            // 
            // lb_cstmprice
            // 
            this.lb_cstmprice.AutoSize = true;
            this.lb_cstmprice.Location = new System.Drawing.Point(143, 242);
            this.lb_cstmprice.Name = "lb_cstmprice";
            this.lb_cstmprice.Size = new System.Drawing.Size(60, 13);
            this.lb_cstmprice.TabIndex = 22;
            this.lb_cstmprice.Text = "Item Price :";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(670, 388);
            this.Controls.Add(this.lb_cstmprice);
            this.Controls.Add(this.lb_cstmname);
            this.Controls.Add(this.lb_uploadinfo);
            this.Controls.Add(this.bt_pbupload);
            this.Controls.Add(this.tx_itemprice);
            this.Controls.Add(this.tx_itemname);
            this.Controls.Add(this.bt_addcart1);
            this.Controls.Add(this.pb_menuupload);
            this.Controls.Add(this.tx_totalprc);
            this.Controls.Add(this.tx_subtotalprc);
            this.Controls.Add(this.lb_totalinfo);
            this.Controls.Add(this.lb_subtotalinfo);
            this.Controls.Add(this.dtgv_shelf);
            this.Name = "Form2";
            this.Text = "Custom Product";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form2_FormClosed);
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_shelf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_menuupload)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dtgv_shelf;
        private System.Windows.Forms.TextBox tx_totalprc;
        private System.Windows.Forms.TextBox tx_subtotalprc;
        private System.Windows.Forms.Label lb_totalinfo;
        private System.Windows.Forms.Label lb_subtotalinfo;
        private System.Windows.Forms.PictureBox pb_menuupload;
        private System.Windows.Forms.Button bt_addcart1;
        private System.Windows.Forms.TextBox tx_itemname;
        private System.Windows.Forms.TextBox tx_itemprice;
        private System.Windows.Forms.Button bt_pbupload;
        private System.Windows.Forms.Label lb_uploadinfo;
        private System.Windows.Forms.Label lb_cstmname;
        private System.Windows.Forms.Label lb_cstmprice;
    }
}
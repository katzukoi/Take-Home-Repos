﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace th9
{
    public partial class Form1 : Form
    {
     

        DataTable dt_topwear = new DataTable();
        DataTable dt_bottomwear = new DataTable();
        DataTable dt_accessories = new DataTable();
        DataTable dt_customothers = new DataTable();
        DataTable dt_cart = new DataTable();

        Form2 lecustomorder;

        public DataTable dt_cache; // Cached Transfer data

        public Form1(Form _form)
        {
            InitializeComponent();
            lecustomorder = _form as Form2;

            dt_cart.Columns.Add("Item Name");
            dt_cart.Columns.Add("Quantity");
            dt_cart.Columns.Add("Price");
            dt_cart.Columns.Add("Total");

            dt_topwear.Columns.Add("Name");
            dt_bottomwear.Columns.Add("Name");
            dt_accessories.Columns.Add("Name");
            dt_customothers.Columns.Add("Name");

            dt_topwear.Columns.Add("Price");
            dt_bottomwear.Columns.Add("Price");
            dt_accessories.Columns.Add("Price");
            dt_customothers.Columns.Add("Price");

            dt_topwear.Rows.Add("DEUS&VEULT.", "Rp.230.000,00");
            dt_topwear.Rows.Add("r0b.c0", "Rp.210.000,00");
            dt_topwear.Rows.Add("WTRMLN.EST", "Rp.330.000,00");

            dt_bottomwear.Rows.Add("CHEPOQUE", "Rp.420.000,00");
            dt_bottomwear.Rows.Add("TLRgulungs", "Rp.230.000,00");
            dt_bottomwear.Rows.Add("PAPedaZ.co", "Rp.620.000,00");

            dt_accessories.Rows.Add("Djawira Clothing", "170.000,00");
            dt_accessories.Rows.Add("THATCHER EXC.", "280.000,00");
            dt_accessories.Rows.Add("alyoma Surplus", "170.000,00");

            dtgv_shelf.DataSource = dt_cart;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (lecustomorder.Barang == null)
            {

            }
            else
            {
                string ItemName2 = lecustomorder.Barang;
                string Itemprc2 = lecustomorder.Harga;
                int Itemqty2 = lecustomorder.Jumlah;

                decimal prc = decimal.Parse(Itemprc2.Replace("Rp.", "").
                    Replace(".", "").Replace(",", ""));
                decimal total = prc * Itemqty2;

                bool exist = false;

                for (int y = 0; y < dt_cart.Rows.Count; y++)
                {
                    DataRow cartrow = dt_cart.Rows[y];

                    if (cartrow["Item Name"].ToString() == ItemName2)
                    {
                        int existingqty = int.Parse(cartrow["Quantity"]
                            .ToString());
                        cartrow["Quantity"] = existingqty + Itemqty2;

                        decimal existingprc = decimal.Parse(cartrow["Price"].
                            ToString().Replace(".", ""));

                        decimal newtotal = existingprc * (existingqty + Itemqty2);
                        cartrow["Total"] = string.Format("Rp.{0:#,##0.00}", newtotal);

                        exist = true;
                        sbtotal();
                        break;
                    } 
                    if (!exist)
                    {
                        dt_cart.Rows.Add(ItemName2, Itemqty2, string.Format("Rp.{0:#,##0.00}", prc),
                            string.Format("Rp.{0:#,##0.00}", total));
                    }
                }
            }
        }

        private void addcart(string itemname,string itemprc)
        {
            string prc_clean = itemprc.Replace("Rp.", "").Replace(".", "").
                Replace(",00", "");
            int price = int.Parse(prc_clean);

            bool exist = false;
            foreach (DataRow cartrow in dt_cart.Rows)
            {
                if (cartrow["Item Name"].ToString() == itemname)
                {
                    int itemqty = int.Parse(cartrow["Quantity"].ToString()) + 1;
                    cartrow["Quantity"] = itemqty;

                    int totalprc = price * itemqty;
                    string totalprcformat = string.Format("Rp.{0:#,##0.00}",
                        totalprc);
                    cartrow["Total"] = totalprcformat;

                    exist = true;
                    break;
                }
                if (!exist)
                {
                    dt_cart.Rows.Add(itemname,1,itemprc,itemprc);
                }
            }
        }

        private void sbtotal()
        {
            string[] subtotal = new string[dt_cart.Rows.Count];
            decimal total = 0;
            for (int i = 0; i < dt_cart.Rows.Count; i++)
            {
                subtotal[i] = dt_cart.Rows[i]["Total"].ToString().Replace("Rp", "").
                    Replace("Rp", "").Replace(",00", "");
            }
            for (int x = 0; x < dt_cart.Rows.Count; x++)
            {
                total += Convert.ToDecimal(subtotal[x].ToString());
            }

            decimal tax = total + (total / 10);

            tx_subtotalprc.Text = String.Format("Rp.{0:#,##0.00}", total);
            tx_totalprc.Text = String.Format("Rp.{0:#,##0.00}", tax);
        }

        public string textboxsubtotal()
        {
            return tx_subtotalprc.Text;
        }

        public string textboxtotal()
        {
            return tx_totalprc.Text;
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lecustomorder = new Form2(dt_cart, textboxsubtotal(), textboxtotal());

            lecustomorder.ShowDialog();
        }
        
        // 0 buat Nama ; 1 buat Harga

        private void topWearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lb_menuname1.Text = dt_topwear.Rows[0][0].ToString();
            lb_menuname2.Text = dt_topwear.Rows[1][0].ToString();
            lb_menuname3.Text = dt_topwear.Rows[2][0].ToString();

            lb_menuprice1.Text = dt_topwear.Rows[0][1].ToString();
            lb_menuprice2.Text = dt_topwear.Rows[1][1].ToString();
            lb_menuprice3.Text = dt_topwear.Rows[2][1].ToString();

            pb_menu1.Show();
            pb_menu2.Show();
            pb_menu3.Show();
        }

        private void bottomWearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lb_menuname1.Text = dt_bottomwear.Rows[0][0].ToString();
            lb_menuname2.Text = dt_bottomwear.Rows[1][0].ToString();
            lb_menuname3.Text = dt_bottomwear.Rows[2][0].ToString();

            lb_menuprice1.Text = dt_bottomwear.Rows[0][1].ToString();
            lb_menuprice2.Text = dt_bottomwear.Rows[1][1].ToString();
            lb_menuprice3.Text = dt_bottomwear.Rows[2][1].ToString();

            pb_menu1.Show();
            pb_menu2.Show();
            pb_menu3.Show();
        }

        private void accessToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lb_menuname1.Text = dt_accessories.Rows[0][0].ToString();
            lb_menuname2.Text = dt_accessories.Rows[1][0].ToString();
            lb_menuname3.Text = dt_accessories.Rows[2][0].ToString();

            lb_menuprice1.Text = dt_accessories.Rows[0][1].ToString();
            lb_menuprice2.Text = dt_accessories.Rows[1][1].ToString();
            lb_menuprice3.Text = dt_accessories.Rows[2][1].ToString();

            pb_menu1.Show();
            pb_menu2.Show();
            pb_menu3.Show();
        }

        private void bt_addcart1_Click(object sender, EventArgs e)
        {
            addcart(lb_menuname1.Text,lb_menuprice1.Text);
            sbtotal();
        }

        private void bt_addcart2_Click(object sender, EventArgs e)
        {
            addcart(lb_menuname2.Text, lb_menuprice2.Text);
            sbtotal();
        }

        private void bt_addcart3_Click(object sender, EventArgs e)
        {
            addcart(lb_menuname3.Text, lb_menuprice3.Text);
            sbtotal();
        }
    }
}

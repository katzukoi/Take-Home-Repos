﻿namespace th9
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewellriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dtgv_shelf = new System.Windows.Forms.DataGridView();
            this.lb_subtotalinfo = new System.Windows.Forms.Label();
            this.lb_totalinfo = new System.Windows.Forms.Label();
            this.tx_subtotalprc = new System.Windows.Forms.TextBox();
            this.tx_totalprc = new System.Windows.Forms.TextBox();
            this.pb_menu1 = new System.Windows.Forms.PictureBox();
            this.pb_menu2 = new System.Windows.Forms.PictureBox();
            this.pb_menu3 = new System.Windows.Forms.PictureBox();
            this.lb_menuname1 = new System.Windows.Forms.Label();
            this.lb_menuname2 = new System.Windows.Forms.Label();
            this.lb_menuname3 = new System.Windows.Forms.Label();
            this.lb_menuprice1 = new System.Windows.Forms.Label();
            this.lb_menuprice2 = new System.Windows.Forms.Label();
            this.lb_menuprice3 = new System.Windows.Forms.Label();
            this.bt_addcart1 = new System.Windows.Forms.Button();
            this.bt_addcart2 = new System.Windows.Forms.Button();
            this.bt_addcart3 = new System.Windows.Forms.Button();
            this.bt_dtdel = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_shelf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_menu1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_menu2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_menu3)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(707, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            this.topWearToolStripMenuItem.Click += new System.EventHandler(this.topWearToolStripMenuItem_Click);
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.shirtToolStripMenuItem.Text = "Shirt";
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            this.bottomWearToolStripMenuItem.Click += new System.EventHandler(this.bottomWearToolStripMenuItem_Click);
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.pantsToolStripMenuItem.Text = "Pants";
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            // 
            // accessToolStripMenuItem
            // 
            this.accessToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewellriesToolStripMenuItem});
            this.accessToolStripMenuItem.Name = "accessToolStripMenuItem";
            this.accessToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.accessToolStripMenuItem.Text = "Accessories";
            this.accessToolStripMenuItem.Click += new System.EventHandler(this.accessToolStripMenuItem_Click);
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.shoesToolStripMenuItem.Text = "Shoes";
            // 
            // jewellriesToolStripMenuItem
            // 
            this.jewellriesToolStripMenuItem.Name = "jewellriesToolStripMenuItem";
            this.jewellriesToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.jewellriesToolStripMenuItem.Text = "Jewellries";
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // dtgv_shelf
            // 
            this.dtgv_shelf.AllowUserToAddRows = false;
            this.dtgv_shelf.AllowUserToDeleteRows = false;
            this.dtgv_shelf.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_shelf.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtgv_shelf.Location = new System.Drawing.Point(381, 42);
            this.dtgv_shelf.Name = "dtgv_shelf";
            this.dtgv_shelf.Size = new System.Drawing.Size(314, 280);
            this.dtgv_shelf.TabIndex = 1;
            // 
            // lb_subtotalinfo
            // 
            this.lb_subtotalinfo.AutoSize = true;
            this.lb_subtotalinfo.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_subtotalinfo.Location = new System.Drawing.Point(380, 338);
            this.lb_subtotalinfo.Name = "lb_subtotalinfo";
            this.lb_subtotalinfo.Size = new System.Drawing.Size(131, 22);
            this.lb_subtotalinfo.TabIndex = 2;
            this.lb_subtotalinfo.Text = "Sub-Total :";
            // 
            // lb_totalinfo
            // 
            this.lb_totalinfo.AutoSize = true;
            this.lb_totalinfo.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_totalinfo.Location = new System.Drawing.Point(424, 362);
            this.lb_totalinfo.Name = "lb_totalinfo";
            this.lb_totalinfo.Size = new System.Drawing.Size(87, 22);
            this.lb_totalinfo.TabIndex = 3;
            this.lb_totalinfo.Text = "Total :";
            // 
            // tx_subtotalprc
            // 
            this.tx_subtotalprc.Location = new System.Drawing.Point(513, 338);
            this.tx_subtotalprc.Name = "tx_subtotalprc";
            this.tx_subtotalprc.Size = new System.Drawing.Size(100, 20);
            this.tx_subtotalprc.TabIndex = 4;
            // 
            // tx_totalprc
            // 
            this.tx_totalprc.Location = new System.Drawing.Point(513, 364);
            this.tx_totalprc.Name = "tx_totalprc";
            this.tx_totalprc.Size = new System.Drawing.Size(100, 20);
            this.tx_totalprc.TabIndex = 5;
            // 
            // pb_menu1
            // 
            this.pb_menu1.Image = ((System.Drawing.Image)(resources.GetObject("pb_menu1.Image")));
            this.pb_menu1.Location = new System.Drawing.Point(12, 42);
            this.pb_menu1.Name = "pb_menu1";
            this.pb_menu1.Size = new System.Drawing.Size(113, 237);
            this.pb_menu1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pb_menu1.TabIndex = 6;
            this.pb_menu1.TabStop = false;
            this.pb_menu1.Visible = false;
            // 
            // pb_menu2
            // 
            this.pb_menu2.Location = new System.Drawing.Point(131, 42);
            this.pb_menu2.Name = "pb_menu2";
            this.pb_menu2.Size = new System.Drawing.Size(113, 237);
            this.pb_menu2.TabIndex = 7;
            this.pb_menu2.TabStop = false;
            this.pb_menu2.Visible = false;
            // 
            // pb_menu3
            // 
            this.pb_menu3.Location = new System.Drawing.Point(250, 42);
            this.pb_menu3.Name = "pb_menu3";
            this.pb_menu3.Size = new System.Drawing.Size(113, 237);
            this.pb_menu3.TabIndex = 8;
            this.pb_menu3.TabStop = false;
            this.pb_menu3.Visible = false;
            // 
            // lb_menuname1
            // 
            this.lb_menuname1.AutoSize = true;
            this.lb_menuname1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_menuname1.Location = new System.Drawing.Point(13, 286);
            this.lb_menuname1.Name = "lb_menuname1";
            this.lb_menuname1.Size = new System.Drawing.Size(56, 15);
            this.lb_menuname1.TabIndex = 9;
            this.lb_menuname1.Text = "Nama ---";
            // 
            // lb_menuname2
            // 
            this.lb_menuname2.AutoSize = true;
            this.lb_menuname2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_menuname2.Location = new System.Drawing.Point(128, 286);
            this.lb_menuname2.Name = "lb_menuname2";
            this.lb_menuname2.Size = new System.Drawing.Size(56, 15);
            this.lb_menuname2.TabIndex = 10;
            this.lb_menuname2.Text = "Nama ---";
            // 
            // lb_menuname3
            // 
            this.lb_menuname3.AutoSize = true;
            this.lb_menuname3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_menuname3.Location = new System.Drawing.Point(247, 286);
            this.lb_menuname3.Name = "lb_menuname3";
            this.lb_menuname3.Size = new System.Drawing.Size(56, 15);
            this.lb_menuname3.TabIndex = 11;
            this.lb_menuname3.Text = "Nama ---";
            // 
            // lb_menuprice1
            // 
            this.lb_menuprice1.AutoSize = true;
            this.lb_menuprice1.Location = new System.Drawing.Point(13, 308);
            this.lb_menuprice1.Name = "lb_menuprice1";
            this.lb_menuprice1.Size = new System.Drawing.Size(48, 13);
            this.lb_menuprice1.TabIndex = 12;
            this.lb_menuprice1.Text = "Harga ---";
            // 
            // lb_menuprice2
            // 
            this.lb_menuprice2.AutoSize = true;
            this.lb_menuprice2.Location = new System.Drawing.Point(128, 309);
            this.lb_menuprice2.Name = "lb_menuprice2";
            this.lb_menuprice2.Size = new System.Drawing.Size(48, 13);
            this.lb_menuprice2.TabIndex = 13;
            this.lb_menuprice2.Text = "Harga ---";
            // 
            // lb_menuprice3
            // 
            this.lb_menuprice3.AutoSize = true;
            this.lb_menuprice3.Location = new System.Drawing.Point(247, 308);
            this.lb_menuprice3.Name = "lb_menuprice3";
            this.lb_menuprice3.Size = new System.Drawing.Size(48, 13);
            this.lb_menuprice3.TabIndex = 14;
            this.lb_menuprice3.Text = "Harga ---";
            // 
            // bt_addcart1
            // 
            this.bt_addcart1.Location = new System.Drawing.Point(16, 335);
            this.bt_addcart1.Name = "bt_addcart1";
            this.bt_addcart1.Size = new System.Drawing.Size(75, 23);
            this.bt_addcart1.TabIndex = 15;
            this.bt_addcart1.Text = "Add 2 Cart";
            this.bt_addcart1.UseVisualStyleBackColor = true;
            this.bt_addcart1.Click += new System.EventHandler(this.bt_addcart1_Click);
            // 
            // bt_addcart2
            // 
            this.bt_addcart2.Location = new System.Drawing.Point(131, 335);
            this.bt_addcart2.Name = "bt_addcart2";
            this.bt_addcart2.Size = new System.Drawing.Size(75, 23);
            this.bt_addcart2.TabIndex = 16;
            this.bt_addcart2.Text = "Add 2 Cart";
            this.bt_addcart2.UseVisualStyleBackColor = true;
            this.bt_addcart2.Click += new System.EventHandler(this.bt_addcart2_Click);
            // 
            // bt_addcart3
            // 
            this.bt_addcart3.Location = new System.Drawing.Point(250, 335);
            this.bt_addcart3.Name = "bt_addcart3";
            this.bt_addcart3.Size = new System.Drawing.Size(75, 23);
            this.bt_addcart3.TabIndex = 17;
            this.bt_addcart3.Text = "Add 2 Cart";
            this.bt_addcart3.UseVisualStyleBackColor = true;
            this.bt_addcart3.Click += new System.EventHandler(this.bt_addcart3_Click);
            // 
            // bt_dtdel
            // 
            this.bt_dtdel.Location = new System.Drawing.Point(620, 338);
            this.bt_dtdel.Name = "bt_dtdel";
            this.bt_dtdel.Size = new System.Drawing.Size(75, 23);
            this.bt_dtdel.TabIndex = 18;
            this.bt_dtdel.Text = "Delete";
            this.bt_dtdel.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(707, 401);
            this.Controls.Add(this.bt_dtdel);
            this.Controls.Add(this.bt_addcart3);
            this.Controls.Add(this.bt_addcart2);
            this.Controls.Add(this.bt_addcart1);
            this.Controls.Add(this.lb_menuprice3);
            this.Controls.Add(this.lb_menuprice2);
            this.Controls.Add(this.lb_menuprice1);
            this.Controls.Add(this.lb_menuname3);
            this.Controls.Add(this.lb_menuname2);
            this.Controls.Add(this.lb_menuname1);
            this.Controls.Add(this.pb_menu3);
            this.Controls.Add(this.pb_menu2);
            this.Controls.Add(this.pb_menu1);
            this.Controls.Add(this.tx_totalprc);
            this.Controls.Add(this.tx_subtotalprc);
            this.Controls.Add(this.lb_totalinfo);
            this.Controls.Add(this.lb_subtotalinfo);
            this.Controls.Add(this.dtgv_shelf);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "WHATCHUWANT.co";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_shelf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_menu1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_menu2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_menu3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewellriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.DataGridView dtgv_shelf;
        private System.Windows.Forms.Label lb_subtotalinfo;
        private System.Windows.Forms.Label lb_totalinfo;
        private System.Windows.Forms.TextBox tx_subtotalprc;
        private System.Windows.Forms.TextBox tx_totalprc;
        private System.Windows.Forms.PictureBox pb_menu1;
        private System.Windows.Forms.PictureBox pb_menu2;
        private System.Windows.Forms.PictureBox pb_menu3;
        private System.Windows.Forms.Label lb_menuname1;
        private System.Windows.Forms.Label lb_menuname2;
        private System.Windows.Forms.Label lb_menuname3;
        private System.Windows.Forms.Label lb_menuprice1;
        private System.Windows.Forms.Label lb_menuprice2;
        private System.Windows.Forms.Label lb_menuprice3;
        private System.Windows.Forms.Button bt_addcart1;
        private System.Windows.Forms.Button bt_addcart2;
        private System.Windows.Forms.Button bt_addcart3;
        private System.Windows.Forms.Button bt_dtdel;
    }
}


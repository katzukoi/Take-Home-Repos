﻿namespace WordGame_TH
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tx_inptusr1 = new System.Windows.Forms.TextBox();
            this.keyboardpanel = new System.Windows.Forms.Panel();
            this.tx_inptusr2 = new System.Windows.Forms.TextBox();
            this.tx_inptusr3 = new System.Windows.Forms.TextBox();
            this.tx_inptusr4 = new System.Windows.Forms.TextBox();
            this.tx_inptusr5 = new System.Windows.Forms.TextBox();
            this.tx_inptinfo1 = new System.Windows.Forms.Label();
            this.tx_inptinfo2 = new System.Windows.Forms.Label();
            this.tx_inptinfo4 = new System.Windows.Forms.Label();
            this.tx_inptinfo3 = new System.Windows.Forms.Label();
            this.tx_inptinfo5 = new System.Windows.Forms.Label();
            this.bt_start = new System.Windows.Forms.Button();
            this.bt_wordreset = new System.Windows.Forms.Button();
            this.tx_wrdchoice1 = new System.Windows.Forms.Label();
            this.tx_wrdchoice2 = new System.Windows.Forms.Label();
            this.tx_wrdchoice3 = new System.Windows.Forms.Label();
            this.tx_wrdchoice5 = new System.Windows.Forms.Label();
            this.tx_wrdchoice4 = new System.Windows.Forms.Label();
            this.bt_keyQ = new System.Windows.Forms.Button();
            this.bt_keyW = new System.Windows.Forms.Button();
            this.bt_keyE = new System.Windows.Forms.Button();
            this.bt_keyR = new System.Windows.Forms.Button();
            this.bt_keyT = new System.Windows.Forms.Button();
            this.bt_keyY = new System.Windows.Forms.Button();
            this.bt_keyU = new System.Windows.Forms.Button();
            this.bt_keyI = new System.Windows.Forms.Button();
            this.bt_keyO = new System.Windows.Forms.Button();
            this.bt_keyP = new System.Windows.Forms.Button();
            this.bt_keyA = new System.Windows.Forms.Button();
            this.bt_keyS = new System.Windows.Forms.Button();
            this.bt_keyD = new System.Windows.Forms.Button();
            this.bt_keyF = new System.Windows.Forms.Button();
            this.bt_keyG = new System.Windows.Forms.Button();
            this.bt_keyH = new System.Windows.Forms.Button();
            this.bt_keyJ = new System.Windows.Forms.Button();
            this.bt_keyK = new System.Windows.Forms.Button();
            this.bt_keyL = new System.Windows.Forms.Button();
            this.bt_keyZ = new System.Windows.Forms.Button();
            this.bt_keyX = new System.Windows.Forms.Button();
            this.bt_keyC = new System.Windows.Forms.Button();
            this.bt_keyV = new System.Windows.Forms.Button();
            this.bt_keyB = new System.Windows.Forms.Button();
            this.bt_keyN = new System.Windows.Forms.Button();
            this.bt_keyM = new System.Windows.Forms.Button();
            this.wintextpanel = new System.Windows.Forms.Panel();
            this.tx_win = new System.Windows.Forms.Label();
            this.bt_debugmode = new System.Windows.Forms.Button();
            this.tx_debug = new System.Windows.Forms.Label();
            this.keyboardpanel.SuspendLayout();
            this.wintextpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // tx_inptusr1
            // 
            this.tx_inptusr1.Location = new System.Drawing.Point(89, 30);
            this.tx_inptusr1.Name = "tx_inptusr1";
            this.tx_inptusr1.Size = new System.Drawing.Size(100, 20);
            this.tx_inptusr1.TabIndex = 0;
            // 
            // keyboardpanel
            // 
            this.keyboardpanel.Controls.Add(this.tx_debug);
            this.keyboardpanel.Controls.Add(this.bt_keyM);
            this.keyboardpanel.Controls.Add(this.bt_keyN);
            this.keyboardpanel.Controls.Add(this.bt_keyB);
            this.keyboardpanel.Controls.Add(this.bt_keyV);
            this.keyboardpanel.Controls.Add(this.bt_keyC);
            this.keyboardpanel.Controls.Add(this.bt_keyX);
            this.keyboardpanel.Controls.Add(this.bt_keyZ);
            this.keyboardpanel.Controls.Add(this.bt_keyL);
            this.keyboardpanel.Controls.Add(this.bt_keyK);
            this.keyboardpanel.Controls.Add(this.bt_keyJ);
            this.keyboardpanel.Controls.Add(this.bt_keyH);
            this.keyboardpanel.Controls.Add(this.bt_keyG);
            this.keyboardpanel.Controls.Add(this.bt_keyF);
            this.keyboardpanel.Controls.Add(this.bt_keyD);
            this.keyboardpanel.Controls.Add(this.bt_keyS);
            this.keyboardpanel.Controls.Add(this.bt_keyA);
            this.keyboardpanel.Controls.Add(this.bt_keyP);
            this.keyboardpanel.Controls.Add(this.bt_keyO);
            this.keyboardpanel.Controls.Add(this.bt_keyI);
            this.keyboardpanel.Controls.Add(this.bt_keyU);
            this.keyboardpanel.Controls.Add(this.bt_keyY);
            this.keyboardpanel.Controls.Add(this.bt_keyT);
            this.keyboardpanel.Controls.Add(this.bt_keyR);
            this.keyboardpanel.Controls.Add(this.bt_keyE);
            this.keyboardpanel.Controls.Add(this.bt_keyW);
            this.keyboardpanel.Controls.Add(this.bt_keyQ);
            this.keyboardpanel.Controls.Add(this.tx_wrdchoice4);
            this.keyboardpanel.Controls.Add(this.tx_wrdchoice5);
            this.keyboardpanel.Controls.Add(this.tx_wrdchoice3);
            this.keyboardpanel.Controls.Add(this.tx_wrdchoice2);
            this.keyboardpanel.Controls.Add(this.tx_wrdchoice1);
            this.keyboardpanel.Location = new System.Drawing.Point(238, 30);
            this.keyboardpanel.Name = "keyboardpanel";
            this.keyboardpanel.Size = new System.Drawing.Size(628, 352);
            this.keyboardpanel.TabIndex = 1;
            this.keyboardpanel.Visible = false;
            // 
            // tx_inptusr2
            // 
            this.tx_inptusr2.Location = new System.Drawing.Point(89, 71);
            this.tx_inptusr2.Name = "tx_inptusr2";
            this.tx_inptusr2.Size = new System.Drawing.Size(100, 20);
            this.tx_inptusr2.TabIndex = 2;
            // 
            // tx_inptusr3
            // 
            this.tx_inptusr3.Location = new System.Drawing.Point(89, 113);
            this.tx_inptusr3.Name = "tx_inptusr3";
            this.tx_inptusr3.Size = new System.Drawing.Size(100, 20);
            this.tx_inptusr3.TabIndex = 3;
            // 
            // tx_inptusr4
            // 
            this.tx_inptusr4.Location = new System.Drawing.Point(89, 159);
            this.tx_inptusr4.Name = "tx_inptusr4";
            this.tx_inptusr4.Size = new System.Drawing.Size(100, 20);
            this.tx_inptusr4.TabIndex = 4;
            // 
            // tx_inptusr5
            // 
            this.tx_inptusr5.Location = new System.Drawing.Point(89, 199);
            this.tx_inptusr5.Name = "tx_inptusr5";
            this.tx_inptusr5.Size = new System.Drawing.Size(100, 20);
            this.tx_inptusr5.TabIndex = 5;
            // 
            // tx_inptinfo1
            // 
            this.tx_inptinfo1.AutoSize = true;
            this.tx_inptinfo1.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_inptinfo1.Location = new System.Drawing.Point(12, 32);
            this.tx_inptinfo1.Name = "tx_inptinfo1";
            this.tx_inptinfo1.Size = new System.Drawing.Size(71, 16);
            this.tx_inptinfo1.TabIndex = 6;
            this.tx_inptinfo1.Text = "Kata 1 :";
            // 
            // tx_inptinfo2
            // 
            this.tx_inptinfo2.AutoSize = true;
            this.tx_inptinfo2.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_inptinfo2.Location = new System.Drawing.Point(12, 75);
            this.tx_inptinfo2.Name = "tx_inptinfo2";
            this.tx_inptinfo2.Size = new System.Drawing.Size(71, 16);
            this.tx_inptinfo2.TabIndex = 7;
            this.tx_inptinfo2.Text = "Kata 2 :";
            // 
            // tx_inptinfo4
            // 
            this.tx_inptinfo4.AutoSize = true;
            this.tx_inptinfo4.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_inptinfo4.Location = new System.Drawing.Point(12, 159);
            this.tx_inptinfo4.Name = "tx_inptinfo4";
            this.tx_inptinfo4.Size = new System.Drawing.Size(71, 16);
            this.tx_inptinfo4.TabIndex = 8;
            this.tx_inptinfo4.Text = "Kata 4 :";
            // 
            // tx_inptinfo3
            // 
            this.tx_inptinfo3.AutoSize = true;
            this.tx_inptinfo3.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_inptinfo3.Location = new System.Drawing.Point(12, 117);
            this.tx_inptinfo3.Name = "tx_inptinfo3";
            this.tx_inptinfo3.Size = new System.Drawing.Size(71, 16);
            this.tx_inptinfo3.TabIndex = 9;
            this.tx_inptinfo3.Text = "Kata 3 :";
            // 
            // tx_inptinfo5
            // 
            this.tx_inptinfo5.AutoSize = true;
            this.tx_inptinfo5.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_inptinfo5.Location = new System.Drawing.Point(12, 203);
            this.tx_inptinfo5.Name = "tx_inptinfo5";
            this.tx_inptinfo5.Size = new System.Drawing.Size(71, 16);
            this.tx_inptinfo5.TabIndex = 10;
            this.tx_inptinfo5.Text = "Kata 5 :";
            // 
            // bt_start
            // 
            this.bt_start.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_start.Location = new System.Drawing.Point(13, 238);
            this.bt_start.Name = "bt_start";
            this.bt_start.Size = new System.Drawing.Size(176, 62);
            this.bt_start.TabIndex = 11;
            this.bt_start.Text = "Start Game";
            this.bt_start.UseVisualStyleBackColor = true;
            this.bt_start.Click += new System.EventHandler(this.bt_start_Click);
            // 
            // bt_wordreset
            // 
            this.bt_wordreset.Location = new System.Drawing.Point(15, 306);
            this.bt_wordreset.Name = "bt_wordreset";
            this.bt_wordreset.Size = new System.Drawing.Size(174, 27);
            this.bt_wordreset.TabIndex = 12;
            this.bt_wordreset.Text = "Clear Word(s)";
            this.bt_wordreset.UseVisualStyleBackColor = true;
            this.bt_wordreset.Click += new System.EventHandler(this.bt_wordreset_Click);
            // 
            // tx_wrdchoice1
            // 
            this.tx_wrdchoice1.AutoSize = true;
            this.tx_wrdchoice1.Font = new System.Drawing.Font("Courier New", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_wrdchoice1.Location = new System.Drawing.Point(222, 87);
            this.tx_wrdchoice1.Name = "tx_wrdchoice1";
            this.tx_wrdchoice1.Size = new System.Drawing.Size(38, 40);
            this.tx_wrdchoice1.TabIndex = 0;
            this.tx_wrdchoice1.Text = "_";
            // 
            // tx_wrdchoice2
            // 
            this.tx_wrdchoice2.AutoSize = true;
            this.tx_wrdchoice2.Font = new System.Drawing.Font("Courier New", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_wrdchoice2.Location = new System.Drawing.Point(266, 87);
            this.tx_wrdchoice2.Name = "tx_wrdchoice2";
            this.tx_wrdchoice2.Size = new System.Drawing.Size(38, 40);
            this.tx_wrdchoice2.TabIndex = 1;
            this.tx_wrdchoice2.Text = "_";
            // 
            // tx_wrdchoice3
            // 
            this.tx_wrdchoice3.AutoSize = true;
            this.tx_wrdchoice3.Font = new System.Drawing.Font("Courier New", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_wrdchoice3.Location = new System.Drawing.Point(310, 87);
            this.tx_wrdchoice3.Name = "tx_wrdchoice3";
            this.tx_wrdchoice3.Size = new System.Drawing.Size(38, 40);
            this.tx_wrdchoice3.TabIndex = 2;
            this.tx_wrdchoice3.Text = "_";
            // 
            // tx_wrdchoice5
            // 
            this.tx_wrdchoice5.AutoSize = true;
            this.tx_wrdchoice5.Font = new System.Drawing.Font("Courier New", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_wrdchoice5.Location = new System.Drawing.Point(398, 87);
            this.tx_wrdchoice5.Name = "tx_wrdchoice5";
            this.tx_wrdchoice5.Size = new System.Drawing.Size(38, 40);
            this.tx_wrdchoice5.TabIndex = 3;
            this.tx_wrdchoice5.Text = "_";
            // 
            // tx_wrdchoice4
            // 
            this.tx_wrdchoice4.AutoSize = true;
            this.tx_wrdchoice4.Font = new System.Drawing.Font("Courier New", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_wrdchoice4.Location = new System.Drawing.Point(354, 87);
            this.tx_wrdchoice4.Name = "tx_wrdchoice4";
            this.tx_wrdchoice4.Size = new System.Drawing.Size(38, 40);
            this.tx_wrdchoice4.TabIndex = 4;
            this.tx_wrdchoice4.Text = "_";
            // 
            // bt_keyQ
            // 
            this.bt_keyQ.Location = new System.Drawing.Point(27, 151);
            this.bt_keyQ.Name = "bt_keyQ";
            this.bt_keyQ.Size = new System.Drawing.Size(52, 58);
            this.bt_keyQ.TabIndex = 5;
            this.bt_keyQ.Text = "Q";
            this.bt_keyQ.UseVisualStyleBackColor = true;
            this.bt_keyQ.Click += new System.EventHandler(this.bt_keyQ_Click);
            // 
            // bt_keyW
            // 
            this.bt_keyW.Location = new System.Drawing.Point(85, 151);
            this.bt_keyW.Name = "bt_keyW";
            this.bt_keyW.Size = new System.Drawing.Size(52, 58);
            this.bt_keyW.TabIndex = 6;
            this.bt_keyW.Text = "W";
            this.bt_keyW.UseVisualStyleBackColor = true;
            this.bt_keyW.Click += new System.EventHandler(this.bt_keyW_Click);
            // 
            // bt_keyE
            // 
            this.bt_keyE.Location = new System.Drawing.Point(143, 151);
            this.bt_keyE.Name = "bt_keyE";
            this.bt_keyE.Size = new System.Drawing.Size(52, 58);
            this.bt_keyE.TabIndex = 7;
            this.bt_keyE.Text = "E";
            this.bt_keyE.UseVisualStyleBackColor = true;
            this.bt_keyE.Click += new System.EventHandler(this.bt_keyE_Click);
            // 
            // bt_keyR
            // 
            this.bt_keyR.Location = new System.Drawing.Point(201, 151);
            this.bt_keyR.Name = "bt_keyR";
            this.bt_keyR.Size = new System.Drawing.Size(52, 58);
            this.bt_keyR.TabIndex = 8;
            this.bt_keyR.Text = "R";
            this.bt_keyR.UseVisualStyleBackColor = true;
            this.bt_keyR.Click += new System.EventHandler(this.bt_keyR_Click);
            // 
            // bt_keyT
            // 
            this.bt_keyT.Location = new System.Drawing.Point(259, 151);
            this.bt_keyT.Name = "bt_keyT";
            this.bt_keyT.Size = new System.Drawing.Size(52, 58);
            this.bt_keyT.TabIndex = 9;
            this.bt_keyT.Text = "T";
            this.bt_keyT.UseVisualStyleBackColor = true;
            this.bt_keyT.Click += new System.EventHandler(this.bt_keyT_Click);
            // 
            // bt_keyY
            // 
            this.bt_keyY.Location = new System.Drawing.Point(317, 151);
            this.bt_keyY.Name = "bt_keyY";
            this.bt_keyY.Size = new System.Drawing.Size(52, 58);
            this.bt_keyY.TabIndex = 10;
            this.bt_keyY.Text = "Y";
            this.bt_keyY.UseVisualStyleBackColor = true;
            this.bt_keyY.Click += new System.EventHandler(this.bt_keyY_Click);
            // 
            // bt_keyU
            // 
            this.bt_keyU.Location = new System.Drawing.Point(375, 151);
            this.bt_keyU.Name = "bt_keyU";
            this.bt_keyU.Size = new System.Drawing.Size(52, 58);
            this.bt_keyU.TabIndex = 11;
            this.bt_keyU.Text = "U";
            this.bt_keyU.UseVisualStyleBackColor = true;
            this.bt_keyU.Click += new System.EventHandler(this.bt_keyU_Click);
            // 
            // bt_keyI
            // 
            this.bt_keyI.Location = new System.Drawing.Point(433, 151);
            this.bt_keyI.Name = "bt_keyI";
            this.bt_keyI.Size = new System.Drawing.Size(52, 58);
            this.bt_keyI.TabIndex = 12;
            this.bt_keyI.Text = "I";
            this.bt_keyI.UseVisualStyleBackColor = true;
            this.bt_keyI.Click += new System.EventHandler(this.bt_keyI_Click);
            // 
            // bt_keyO
            // 
            this.bt_keyO.Location = new System.Drawing.Point(491, 151);
            this.bt_keyO.Name = "bt_keyO";
            this.bt_keyO.Size = new System.Drawing.Size(52, 58);
            this.bt_keyO.TabIndex = 13;
            this.bt_keyO.Text = "O";
            this.bt_keyO.UseVisualStyleBackColor = true;
            this.bt_keyO.Click += new System.EventHandler(this.bt_keyO_Click);
            // 
            // bt_keyP
            // 
            this.bt_keyP.Location = new System.Drawing.Point(549, 151);
            this.bt_keyP.Name = "bt_keyP";
            this.bt_keyP.Size = new System.Drawing.Size(52, 58);
            this.bt_keyP.TabIndex = 14;
            this.bt_keyP.Text = "P";
            this.bt_keyP.UseVisualStyleBackColor = true;
            this.bt_keyP.Click += new System.EventHandler(this.bt_keyP_Click);
            // 
            // bt_keyA
            // 
            this.bt_keyA.Location = new System.Drawing.Point(53, 215);
            this.bt_keyA.Name = "bt_keyA";
            this.bt_keyA.Size = new System.Drawing.Size(52, 58);
            this.bt_keyA.TabIndex = 15;
            this.bt_keyA.Text = "A";
            this.bt_keyA.UseVisualStyleBackColor = true;
            this.bt_keyA.Click += new System.EventHandler(this.bt_keyA_Click);
            // 
            // bt_keyS
            // 
            this.bt_keyS.Location = new System.Drawing.Point(111, 215);
            this.bt_keyS.Name = "bt_keyS";
            this.bt_keyS.Size = new System.Drawing.Size(52, 58);
            this.bt_keyS.TabIndex = 16;
            this.bt_keyS.Text = "S";
            this.bt_keyS.UseVisualStyleBackColor = true;
            this.bt_keyS.Click += new System.EventHandler(this.bt_keyS_Click);
            // 
            // bt_keyD
            // 
            this.bt_keyD.Location = new System.Drawing.Point(169, 215);
            this.bt_keyD.Name = "bt_keyD";
            this.bt_keyD.Size = new System.Drawing.Size(52, 58);
            this.bt_keyD.TabIndex = 17;
            this.bt_keyD.Text = "D";
            this.bt_keyD.UseVisualStyleBackColor = true;
            this.bt_keyD.Click += new System.EventHandler(this.bt_keyD_Click);
            // 
            // bt_keyF
            // 
            this.bt_keyF.Location = new System.Drawing.Point(227, 214);
            this.bt_keyF.Name = "bt_keyF";
            this.bt_keyF.Size = new System.Drawing.Size(52, 58);
            this.bt_keyF.TabIndex = 18;
            this.bt_keyF.Text = "F";
            this.bt_keyF.UseVisualStyleBackColor = true;
            this.bt_keyF.Click += new System.EventHandler(this.bt_keyF_Click);
            // 
            // bt_keyG
            // 
            this.bt_keyG.Location = new System.Drawing.Point(285, 214);
            this.bt_keyG.Name = "bt_keyG";
            this.bt_keyG.Size = new System.Drawing.Size(52, 58);
            this.bt_keyG.TabIndex = 19;
            this.bt_keyG.Text = "G";
            this.bt_keyG.UseVisualStyleBackColor = true;
            this.bt_keyG.Click += new System.EventHandler(this.bt_keyG_Click);
            // 
            // bt_keyH
            // 
            this.bt_keyH.Location = new System.Drawing.Point(343, 215);
            this.bt_keyH.Name = "bt_keyH";
            this.bt_keyH.Size = new System.Drawing.Size(52, 58);
            this.bt_keyH.TabIndex = 20;
            this.bt_keyH.Text = "H";
            this.bt_keyH.UseVisualStyleBackColor = true;
            this.bt_keyH.Click += new System.EventHandler(this.bt_keyH_Click);
            // 
            // bt_keyJ
            // 
            this.bt_keyJ.Location = new System.Drawing.Point(401, 214);
            this.bt_keyJ.Name = "bt_keyJ";
            this.bt_keyJ.Size = new System.Drawing.Size(52, 58);
            this.bt_keyJ.TabIndex = 21;
            this.bt_keyJ.Text = "J";
            this.bt_keyJ.UseVisualStyleBackColor = true;
            this.bt_keyJ.Click += new System.EventHandler(this.bt_keyJ_Click);
            // 
            // bt_keyK
            // 
            this.bt_keyK.Location = new System.Drawing.Point(459, 215);
            this.bt_keyK.Name = "bt_keyK";
            this.bt_keyK.Size = new System.Drawing.Size(52, 58);
            this.bt_keyK.TabIndex = 22;
            this.bt_keyK.Text = "K";
            this.bt_keyK.UseVisualStyleBackColor = true;
            this.bt_keyK.Click += new System.EventHandler(this.bt_keyK_Click);
            // 
            // bt_keyL
            // 
            this.bt_keyL.Location = new System.Drawing.Point(517, 215);
            this.bt_keyL.Name = "bt_keyL";
            this.bt_keyL.Size = new System.Drawing.Size(52, 58);
            this.bt_keyL.TabIndex = 23;
            this.bt_keyL.Text = "L";
            this.bt_keyL.UseVisualStyleBackColor = true;
            this.bt_keyL.Click += new System.EventHandler(this.bt_keyL_Click);
            // 
            // bt_keyZ
            // 
            this.bt_keyZ.Location = new System.Drawing.Point(85, 279);
            this.bt_keyZ.Name = "bt_keyZ";
            this.bt_keyZ.Size = new System.Drawing.Size(52, 58);
            this.bt_keyZ.TabIndex = 24;
            this.bt_keyZ.Text = "Z";
            this.bt_keyZ.UseVisualStyleBackColor = true;
            this.bt_keyZ.Click += new System.EventHandler(this.bt_keyZ_Click);
            // 
            // bt_keyX
            // 
            this.bt_keyX.Location = new System.Drawing.Point(143, 279);
            this.bt_keyX.Name = "bt_keyX";
            this.bt_keyX.Size = new System.Drawing.Size(52, 58);
            this.bt_keyX.TabIndex = 25;
            this.bt_keyX.Text = "X";
            this.bt_keyX.UseVisualStyleBackColor = true;
            this.bt_keyX.Click += new System.EventHandler(this.bt_keyX_Click);
            // 
            // bt_keyC
            // 
            this.bt_keyC.Location = new System.Drawing.Point(201, 279);
            this.bt_keyC.Name = "bt_keyC";
            this.bt_keyC.Size = new System.Drawing.Size(52, 58);
            this.bt_keyC.TabIndex = 26;
            this.bt_keyC.Text = "C";
            this.bt_keyC.UseVisualStyleBackColor = true;
            this.bt_keyC.Click += new System.EventHandler(this.bt_keyC_Click);
            // 
            // bt_keyV
            // 
            this.bt_keyV.Location = new System.Drawing.Point(259, 278);
            this.bt_keyV.Name = "bt_keyV";
            this.bt_keyV.Size = new System.Drawing.Size(52, 58);
            this.bt_keyV.TabIndex = 27;
            this.bt_keyV.Text = "V";
            this.bt_keyV.UseVisualStyleBackColor = true;
            this.bt_keyV.Click += new System.EventHandler(this.bt_keyV_Click);
            // 
            // bt_keyB
            // 
            this.bt_keyB.Location = new System.Drawing.Point(317, 279);
            this.bt_keyB.Name = "bt_keyB";
            this.bt_keyB.Size = new System.Drawing.Size(52, 58);
            this.bt_keyB.TabIndex = 28;
            this.bt_keyB.Text = "B";
            this.bt_keyB.UseVisualStyleBackColor = true;
            this.bt_keyB.Click += new System.EventHandler(this.bt_keyB_Click);
            // 
            // bt_keyN
            // 
            this.bt_keyN.Location = new System.Drawing.Point(375, 279);
            this.bt_keyN.Name = "bt_keyN";
            this.bt_keyN.Size = new System.Drawing.Size(52, 58);
            this.bt_keyN.TabIndex = 29;
            this.bt_keyN.Text = "N";
            this.bt_keyN.UseVisualStyleBackColor = true;
            this.bt_keyN.Click += new System.EventHandler(this.bt_keyN_Click);
            // 
            // bt_keyM
            // 
            this.bt_keyM.Location = new System.Drawing.Point(433, 279);
            this.bt_keyM.Name = "bt_keyM";
            this.bt_keyM.Size = new System.Drawing.Size(52, 58);
            this.bt_keyM.TabIndex = 30;
            this.bt_keyM.Text = "M";
            this.bt_keyM.UseVisualStyleBackColor = true;
            this.bt_keyM.Click += new System.EventHandler(this.bt_keyM_Click);
            // 
            // wintextpanel
            // 
            this.wintextpanel.Controls.Add(this.tx_win);
            this.wintextpanel.Location = new System.Drawing.Point(407, 401);
            this.wintextpanel.Name = "wintextpanel";
            this.wintextpanel.Size = new System.Drawing.Size(305, 39);
            this.wintextpanel.TabIndex = 13;
            this.wintextpanel.Visible = false;
            // 
            // tx_win
            // 
            this.tx_win.AutoSize = true;
            this.tx_win.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_win.Location = new System.Drawing.Point(10, 9);
            this.tx_win.Name = "tx_win";
            this.tx_win.Size = new System.Drawing.Size(285, 21);
            this.tx_win.TabIndex = 0;
            this.tx_win.Text = "Congratulations! You win!";
            // 
            // bt_debugmode
            // 
            this.bt_debugmode.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_debugmode.Location = new System.Drawing.Point(12, 452);
            this.bt_debugmode.Name = "bt_debugmode";
            this.bt_debugmode.Size = new System.Drawing.Size(94, 29);
            this.bt_debugmode.TabIndex = 14;
            this.bt_debugmode.Text = "Debug";
            this.bt_debugmode.UseVisualStyleBackColor = true;
            this.bt_debugmode.Click += new System.EventHandler(this.bt_debugmode_Click);
            // 
            // tx_debug
            // 
            this.tx_debug.AutoSize = true;
            this.tx_debug.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_debug.Location = new System.Drawing.Point(569, 17);
            this.tx_debug.Name = "tx_debug";
            this.tx_debug.Size = new System.Drawing.Size(42, 14);
            this.tx_debug.TabIndex = 31;
            this.tx_debug.Text = "-----";
            this.tx_debug.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(878, 493);
            this.Controls.Add(this.bt_debugmode);
            this.Controls.Add(this.wintextpanel);
            this.Controls.Add(this.bt_wordreset);
            this.Controls.Add(this.bt_start);
            this.Controls.Add(this.tx_inptinfo5);
            this.Controls.Add(this.tx_inptinfo3);
            this.Controls.Add(this.tx_inptinfo4);
            this.Controls.Add(this.tx_inptinfo2);
            this.Controls.Add(this.tx_inptinfo1);
            this.Controls.Add(this.tx_inptusr5);
            this.Controls.Add(this.tx_inptusr4);
            this.Controls.Add(this.tx_inptusr3);
            this.Controls.Add(this.tx_inptusr2);
            this.Controls.Add(this.keyboardpanel);
            this.Controls.Add(this.tx_inptusr1);
            this.Name = "Form1";
            this.Text = "Word Game Alpha 0.0.1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.keyboardpanel.ResumeLayout(false);
            this.keyboardpanel.PerformLayout();
            this.wintextpanel.ResumeLayout(false);
            this.wintextpanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tx_inptusr1;
        private System.Windows.Forms.Panel keyboardpanel;
        private System.Windows.Forms.TextBox tx_inptusr2;
        private System.Windows.Forms.TextBox tx_inptusr3;
        private System.Windows.Forms.TextBox tx_inptusr4;
        private System.Windows.Forms.TextBox tx_inptusr5;
        private System.Windows.Forms.Label tx_inptinfo1;
        private System.Windows.Forms.Label tx_inptinfo2;
        private System.Windows.Forms.Label tx_inptinfo4;
        private System.Windows.Forms.Label tx_inptinfo3;
        private System.Windows.Forms.Label tx_inptinfo5;
        private System.Windows.Forms.Button bt_start;
        private System.Windows.Forms.Button bt_wordreset;
        private System.Windows.Forms.Label tx_wrdchoice4;
        private System.Windows.Forms.Label tx_wrdchoice5;
        private System.Windows.Forms.Label tx_wrdchoice3;
        private System.Windows.Forms.Label tx_wrdchoice2;
        private System.Windows.Forms.Label tx_wrdchoice1;
        private System.Windows.Forms.Button bt_keyP;
        private System.Windows.Forms.Button bt_keyO;
        private System.Windows.Forms.Button bt_keyI;
        private System.Windows.Forms.Button bt_keyU;
        private System.Windows.Forms.Button bt_keyY;
        private System.Windows.Forms.Button bt_keyT;
        private System.Windows.Forms.Button bt_keyR;
        private System.Windows.Forms.Button bt_keyE;
        private System.Windows.Forms.Button bt_keyW;
        private System.Windows.Forms.Button bt_keyQ;
        private System.Windows.Forms.Button bt_keyM;
        private System.Windows.Forms.Button bt_keyN;
        private System.Windows.Forms.Button bt_keyB;
        private System.Windows.Forms.Button bt_keyV;
        private System.Windows.Forms.Button bt_keyC;
        private System.Windows.Forms.Button bt_keyX;
        private System.Windows.Forms.Button bt_keyZ;
        private System.Windows.Forms.Button bt_keyL;
        private System.Windows.Forms.Button bt_keyK;
        private System.Windows.Forms.Button bt_keyJ;
        private System.Windows.Forms.Button bt_keyH;
        private System.Windows.Forms.Button bt_keyG;
        private System.Windows.Forms.Button bt_keyF;
        private System.Windows.Forms.Button bt_keyD;
        private System.Windows.Forms.Button bt_keyS;
        private System.Windows.Forms.Button bt_keyA;
        private System.Windows.Forms.Panel wintextpanel;
        private System.Windows.Forms.Label tx_win;
        private System.Windows.Forms.Label tx_debug;
        private System.Windows.Forms.Button bt_debugmode;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WordGame_TH
{
    public partial class Form1 : Form
    {
        private int wincon = 0;
        private string keyboardletter_clicked = "";
        private List<string> letter = new List<string>() { " "," "," "," "," "};

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void bt_start_Click(object sender, EventArgs e)
        {
            int wordrnd1 = tx_inptusr1.Text.Length;
            int wordrnd2 = tx_inptusr2.Text.Length;
            int wordrnd3 = tx_inptusr3.Text.Length;
            int wordrnd4 = tx_inptusr4.Text.Length;
            int wordrnd5 = tx_inptusr5.Text.Length;

            Random rnd = new Random();
            int rnum = rnd.Next(1, 6);

            string choiceword = "";
            int x = 0;

            if (wordrnd1 == 5 && wordrnd2 == 5 && wordrnd3 == 5 && wordrnd4 == 5 && wordrnd5 == 5 &&
                tx_inptusr1.Text != tx_inptusr2.Text && tx_inptusr1.Text != tx_inptusr3.Text && tx_inptusr1.Text != tx_inptusr4.Text && tx_inptusr1.Text != tx_inptusr5.Text &&
                tx_inptusr2.Text != tx_inptusr3.Text && tx_inptusr2.Text != tx_inptusr4.Text && tx_inptusr2.Text != tx_inptusr5.Text &&
                tx_inptusr3.Text != tx_inptusr4.Text && tx_inptusr3.Text != tx_inptusr5.Text &&
                tx_inptusr4.Text != tx_inptusr5.Text)
            {
                keyboardpanel.Visible = true;
                tx_inptusr1.Visible = false;
                tx_inptusr2.Visible = false;
                tx_inptusr3.Visible = false;
                tx_inptusr4.Visible = false;
                tx_inptusr5.Visible = false;

                if (rnum == 1)
                {
                    choiceword = tx_inptusr1.Text;
                }
                else if (rnum == 2)
                {
                    choiceword = tx_inptusr2.Text;
                }
                else if (rnum == 3)
                {
                    choiceword = tx_inptusr3.Text;
                }
                else if (rnum == 4)
                {
                    choiceword = tx_inptusr4.Text;
                }
                else if (rnum == 5)
                {
                    choiceword = tx_inptusr5.Text;
                }
                foreach (char ltr in choiceword)
                {
                   string letters = ltr.ToString();
                    letter[x] = letters;
                    x++;
                }
                tx_debug.Text = choiceword;
            }
            else
            {
                MessageBox.Show ("Invalid Input, Please try Again");
            }
        }

        private void bt_keyQ_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "q";
            txupdate();
        }

        private void bt_keyW_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "w";
            txupdate();
        }

        private void bt_keyE_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "e";
            txupdate();
        }

        private void bt_keyR_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "r";
            txupdate();
        }

        private void bt_keyT_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "t";
            txupdate();
        }

        private void bt_keyY_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "y";
            txupdate();
        }

        private void bt_keyU_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "u";
            txupdate();
        }

        private void bt_keyI_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "i";
            txupdate();
        }

        private void bt_keyO_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "o";
            txupdate();
        }

        private void bt_keyP_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "p";
            txupdate();
        }

        private void bt_keyA_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "a";
            txupdate();
        }

        private void bt_keyS_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "s";
            txupdate();
        }

        private void bt_keyD_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "d";
            txupdate();
        }

        private void bt_keyF_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "f";
            txupdate();
        }

        private void bt_keyG_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "g";
            txupdate();
        }

        private void bt_keyH_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "h";
            txupdate();
        }

        private void bt_keyJ_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "j";
            txupdate();
        }

        private void bt_keyK_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "k";
            txupdate();
        }

        private void bt_keyL_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "l";
            txupdate();
        }

        private void bt_keyZ_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "z";
            txupdate();
        }

        private void bt_keyX_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "x";
            txupdate();
        }

        private void bt_keyC_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "c";
            txupdate();
        }

        private void bt_keyV_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "v";
            txupdate();
        }

        private void bt_keyB_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "b";
            txupdate();
        }

        private void bt_keyN_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "n";
            txupdate();
        }

        private void bt_keyM_Click(object sender, EventArgs e)
        {
            keyboardletter_clicked = "m";
            txupdate();
        }

        private void txupdate()
        {
            if (keyboardletter_clicked == letter[0])
            {
                tx_wrdchoice1.Text = keyboardletter_clicked;
                wincon++;
            }
            if (keyboardletter_clicked == letter[1])
            {
                tx_wrdchoice2.Text = keyboardletter_clicked;
                wincon++;
            }
            if (keyboardletter_clicked == letter[2])
            {
                tx_wrdchoice3.Text = keyboardletter_clicked;
                wincon++;
            }
            if (keyboardletter_clicked == letter[3])
            {
                tx_wrdchoice4.Text = keyboardletter_clicked;
                wincon++;
            }
            if (keyboardletter_clicked == letter[4])
            {
                tx_wrdchoice5.Text = keyboardletter_clicked;
                wincon++;
            }
            if (wincon == 5)
            {
                wintextpanel.Visible = true;
            }
        }

        private void bt_wordreset_Click(object sender, EventArgs e)
        {
            MessageBox.Show("i don't know how to make this work rn,soz ;~;)"); 
        }

        private void bt_debugmode_Click(object sender, EventArgs e)
        {
            
            tx_debug.Visible = true;
        }
    }
}

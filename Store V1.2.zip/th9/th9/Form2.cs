﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace th9
{
    public partial class Form2 : Form
    {
        public string Barang { get; private set; }
        public int Jumlah { get; private set; }
        public string Harga { get; private set; }

        public Form2(DataTable dt_form2,string subtotal, string total)
        {
            InitializeComponent();

            dtgv_shelf.DataSource = dt_form2;

            tx_subtotalprc.Text = subtotal;
            tx_totalprc.Text = total;
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void bt_addcart1_Click(object sender, EventArgs e)
        {
            if (Barang == tx_itemname.Text)
            {
                Jumlah++;
            }
            else
            {
                Barang = tx_itemname.Text;
                Harga = tx_itemprice.Text;
                Jumlah = 1;
            }
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void tx_itemprice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void bt_pbupload_Click(object sender, EventArgs e)
        {

        }
    }
}
